# Required quality gates and honest coverage accounting

| Gate | Current reference package | Required in each product |
|---|---|---|
| Structure + skill format | `python tools/check_framework.py` | Keep passed and reviewed |
| Reference authorization negative cases | `python -m unittest discover -s tests -v` | Replace/add real HTTP tests |
| SAST | Semgrep `p/security-audit` in GitHub Actions (external network required) | Confirm language support, configure exceptions |
| Dependency review | Optional GitHub Action; depends on GitHub plan/repository | Enable or use comparable scanner |
| Secret scanning | **Not configured** | Add company-approved secret scanner incl. git history |
| Dynamic app tests | **Not configured** | AuthN/AuthZ/CSRF and abuse tests against deployed test environment |
| Deployment / IaC scanning | **Not configured** | Set up for hosting and IaC technology |
| Human security sign-off | **Required** | Record reviewer and evidence |

**Release policy:** A passing framework pipeline is not a release approval. Enforce the product's application-security-tests job and missing scanners through branch protection / rulesets; set project-specific CI commands. Optional job skip is NOT a pass. Do not use `continue-on-error` for security gates. Pin third-party actions/images to full commit SHA before enterprise rollout and review update process. Classify exceptions with owner, expiration and compensating controls.
