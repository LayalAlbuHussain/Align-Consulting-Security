---
name: company-api-security
description: Apply the company web security standard when creating or reviewing REST or GraphQL APIs, endpoints, input schemas, API tokens, and rate limits.
---

# Api Security skill

## Prerequisites
Read the repository's `policy/SECURITY_POLICY.md` (or the project's linked approved policy). Relevant controls: SEC-003 SEC-004 SEC-005. If the policy is unavailable, disclose this gap and do not claim compliance.

## Workflow
1. Identify affected frontend/backend/API components, actors, trust boundaries, sensitive data and assets.
2. Write a small threat-model note and map applicable company controls.
3. Implement secure defaults and state assumptions; do not fabricate permissions or silently weaken requirements.
4. Document each endpoint, caller, object-level access rule, input/output schema, rate/resource budgets and error shape. Enforce authentication and authorization at service boundary; test BOLA, excessive fields and pagination abuse.
5. Run relevant tests if executable access exists; otherwise provide exact tests to run. Record evidence, failing cases and residual risks.
6. Report: changes, control IDs, tests and outcomes (run/not run), open risks, and approvals needed.

## Non-negotiables
- Never trust browser-only permissions or client-supplied identity/tenant/role.
- Never put secrets, credentials or personal data into logs, prompts or source.
- Do not disable checks, use fake passing test output, or call a feature secure based solely on this skill.
- Refer suspected policy conflicts and exceptions to AppSec.
