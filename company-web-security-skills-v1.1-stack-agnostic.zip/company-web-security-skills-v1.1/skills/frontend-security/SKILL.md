---
name: company-frontend-security
description: Apply the company web security standard when building or reviewing dashboard browser UI, rendering, CSP, cookies, and frontend data handling.
---

# Frontend Security skill

## Prerequisites
Read the repository's `policy/SECURITY_POLICY.md` (or the project's linked approved policy). Relevant controls: SEC-004 SEC-008. If the policy is unavailable, disclose this gap and do not claim compliance.

## Workflow
1. Identify affected frontend/backend/API components, actors, trust boundaries, sensitive data and assets.
2. Write a small threat-model note and map applicable company controls.
3. Implement secure defaults and state assumptions; do not fabricate permissions or silently weaken requirements.
4. Use framework-safe rendering; never inject untrusted HTML unless sanitized with approved libraries. Avoid secrets in client bundles and unsafe browser storage. Verify CSP, security headers and errors without exposing sensitive data.
5. Run relevant tests if executable access exists; otherwise provide exact tests to run. Record evidence, failing cases and residual risks.
6. Report: changes, control IDs, tests and outcomes (run/not run), open risks, and approvals needed.

## Non-negotiables
- Never trust browser-only permissions or client-supplied identity/tenant/role.
- Never put secrets, credentials or personal data into logs, prompts or source.
- Do not disable checks, use fake passing test output, or call a feature secure based solely on this skill.
- Refer suspected policy conflicts and exceptions to AppSec.
