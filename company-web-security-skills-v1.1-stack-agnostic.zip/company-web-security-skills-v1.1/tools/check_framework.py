"""Fail-closed structural checks for the SKILLS pack; not an app security scanner."""
from pathlib import Path
import sys

root=Path(__file__).resolve().parents[1]
required=["policy/SECURITY_POLICY.md", "policy/CONTROL_MATRIX.csv", ".github/workflows/security.yml", "tests/test_authorization.py"]
required += [f"skills/{x}/SKILL.md" for x in ("authentication", "authorization", "frontend-security", "api-security", "data-protection", "backend-security", "audit-logging", "security-review")]
errors=[]
for name in required:
    f=root/name
    if not f.is_file() or not f.read_text(encoding="utf-8").strip(): errors.append(f"Missing/empty {name}")
for p in (root/'skills').glob('*/SKILL.md'):
    t=p.read_text(encoding='utf-8')
    if not t.startswith('---\n') or 'name:' not in t or 'description:' not in t: errors.append(f"Bad skill frontmatter: {p}")
if errors:
    print('\n'.join(errors),file=sys.stderr);sys.exit(1)
print(f'Framework structure: PASS ({len(required)} required files)')
