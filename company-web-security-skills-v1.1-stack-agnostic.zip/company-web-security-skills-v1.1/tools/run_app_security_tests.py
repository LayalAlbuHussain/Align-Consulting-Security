"""Require an actual application security test command from environment.
Do not count framework example tests as evidence of application compliance.
"""
import os, shlex, subprocess, sys
command=os.environ.get('APP_SECURITY_TEST_COMMAND','').strip()
if not command:
    print('APP_SECURITY_TEST_COMMAND not set: app integration security tests are REQUIRED before production.',file=sys.stderr)
    sys.exit(2)
args=shlex.split(command)
if not args:
    sys.exit(2)
print('Running app security test command:',args[0])
sys.exit(subprocess.call(args))
