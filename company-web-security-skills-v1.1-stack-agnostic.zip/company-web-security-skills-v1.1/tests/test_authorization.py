import importlib.util
from pathlib import Path
import unittest

MODULE = Path(__file__).resolve().parents[1] / "examples/python-reference/authorization.py"
spec = importlib.util.spec_from_file_location("reference_auth", MODULE)
module = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = module
spec.loader.exec_module(module)
Principal, Record, allowed, require_allowed = module.Principal, module.Record, module.allowed, module.require_allowed

class TestAuthorization(unittest.TestCase):
    def setUp(self):
        self.owned = Record("r1", "tenant-a", "u1")
        self.other_user = Record("r2", "tenant-a", "u2")
        self.other_tenant = Record("r3", "tenant-b", "u1")
    def test_denies_anonymous(self):
        self.assertFalse(allowed(None, "read", self.owned))
    def test_denies_cross_tenant_even_admin(self):
        self.assertFalse(allowed(Principal("u1", "tenant-a", "admin"), "read", self.other_tenant))
    def test_denies_cross_user_even_manager(self):
        self.assertFalse(allowed(Principal("u1", "tenant-a", "manager"), "read", self.other_user))
    def test_viewer_cannot_write(self):
        self.assertFalse(allowed(Principal("u1", "tenant-a", "viewer"), "write", self.owned))
    def test_unknown_role_action_and_missing_resource(self):
        self.assertFalse(allowed(Principal("u1", "tenant-a", "root"), "read", self.owned))
        self.assertFalse(allowed(Principal("u1", "tenant-a", "admin"), "export-all", self.owned))
        self.assertFalse(allowed(Principal("u1", "tenant-a", "admin"), "read", None))
    def test_admin_allowed_same_tenant(self):
        self.assertTrue(allowed(Principal("u1", "tenant-a", "admin"), "delete", self.owned))
    def test_ownership_and_exception(self):
        self.assertTrue(allowed(Principal("u1", "tenant-a", "viewer"), "read", self.owned))
        with self.assertRaises(PermissionError):
            require_allowed(Principal("u1", "tenant-a", "viewer"), "write", self.owned)

if __name__ == "__main__": unittest.main()
