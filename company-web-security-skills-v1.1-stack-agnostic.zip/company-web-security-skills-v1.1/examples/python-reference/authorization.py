"""Dependency-free reference: adapt to your real identity provider and database.
This module illustrates a deny-by-default ownership/tenant check, NOT complete auth.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class Principal:
    user_id: str
    tenant_id: str
    role: str

@dataclass(frozen=True)
class Record:
    id: str
    tenant_id: str
    owner_id: str

ALLOWED_ACTIONS = {
    "admin": frozenset({"read", "write", "delete"}),
    "manager": frozenset({"read", "write"}),
    "viewer": frozenset({"read"}),
}

def allowed(principal: Principal | None, action: str, record: Record | None) -> bool:
    """No user, unknown action/role, missing resource, or wrong tenant => deny."""
    if principal is None or record is None:
        return False
    if not principal.user_id or not principal.tenant_id or not record.tenant_id:
        return False
    if principal.tenant_id != record.tenant_id:
        return False
    if action not in ALLOWED_ACTIONS.get(principal.role, frozenset()):
        return False
    if principal.role == "admin":
        return True
    # illustrative: even managers only access their own records
    return principal.user_id == record.owner_id

def require_allowed(principal: Principal | None, action: str, record: Record | None) -> None:
    if not allowed(principal, action, record):
        raise PermissionError("Forbidden")
