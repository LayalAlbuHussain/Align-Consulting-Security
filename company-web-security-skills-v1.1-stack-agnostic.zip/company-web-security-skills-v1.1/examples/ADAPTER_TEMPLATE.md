# Stack adapter contract (copy per project)

Fill and have AppSec approve before claiming any project coverage.

- Runtime / frameworks / versions: **TBD**
- Auth identity source (OIDC/SAML/session): **TBD**
- User and tenant IDs derived from verified backend claims, never request body: **TBD**
- Authorization enforcement location (middleware + resource query constraints): **TBD**
- DB access control and parameterization: **TBD**
- Schema validation / CSRF / CORS / CSP: **TBD**
- Secret store and log redaction: **TBD**
- Application security test command (real HTTP API tests against test DB): **TBD**
- SAST and dependency scan supported language coverage: **TBD**
- Security owner, version, exceptions, sign-off: **TBD**

## Required negative HTTP tests (replace with your framework's test runner)

1. GET /api/records/:id without authentication => 401.
2. GET an existing record of another tenant => 403 or indistinguishable 404.
3. GET another user's record where policy disallows access => 403/404.
4. POST or PATCH with viewer identity => 403.
5. POST with user-supplied tenant_id different from verified identity => deny; no database write.
6. Elevated role claimed in request body/header without trusted issuer => deny.
7. Bad input types/oversize payload => 400/413 as configured; never 500 with internal details.
8. Write to protected endpoint without valid CSRF protection when cookie-auth => reject.
9. Sensitive fields absent from unauthorized response and audit log.
10. Authentication expiration/revocation => request rejected.

Use isolated fixture tenants and verify database state remains unchanged after denials.
