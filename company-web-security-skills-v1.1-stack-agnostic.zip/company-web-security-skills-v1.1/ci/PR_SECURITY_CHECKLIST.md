# PR Security Review Checklist
- [ ] Feature has threat/risk analysis proportionate to impact.
- [ ] API checks authentication and authorization, including object/tenant scope.
- [ ] Negative tests show unauthorized users cannot read or mutate protected resources.
- [ ] Inputs validated; DB queries parameterized; output safely rendered.
- [ ] Secrets absent from commits, telemetry, prompts, and frontend bundles.
- [ ] Sensitive data minimized; audit events present without secrets or raw PII.
- [ ] CI tests, SAST, dependency and secret scans pass under configured blocking thresholds.
- [ ] Security owner approves relevant high-risk flows; exceptions documented.
