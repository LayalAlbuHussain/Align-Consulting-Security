# Company Web Security Skills Framework v1.1 — stack-agnostic package

This update extends v1.0 with **executable reference authorization tests**, a real example GitHub Actions workflow, Semgrep scanning, an optional GitHub dependency review, and a stack adapter checklist. **It is not certified, not production-ready, and not a security guarantee.**

## Approach
- `policy/`: organization rules and explicit quality-gate coverage.
- `skills/`: reusable AI guidance independent of implementation language.
- `examples/python-reference/authorization.py`: a dependency-free EXAMPLE to demonstrate deny-by-default and tenant/object authorization. It is not a substitute for your app's identity and database integration.
- `examples/ADAPTER_TEMPLATE.md`: fill this when the real frontend/backend/API stack is known.
- `.github/workflows/security.yml`: example executable framework structural tests, reference unit tests, and Semgrep SAST job. Requires GitHub-hosted runner + external package/rule registry access.
- `.github/workflows/dependency-review-optional.yml`: GitHub dependency review on PRs; needs plan and availability verification.
- `tools/run_app_security_tests.py`: fails without a real project-defined command; the CI job is conditional and **must be made mandatory** by the project owner to prevent skips.

## Run reference checks locally
```bash
python tools/check_framework.py
python -m unittest discover -s tests -v
```
Run SAST where Semgrep is installed and network/rules are available:
```bash
semgrep scan --config p/security-audit --error .
```

## AI installation
- Claude Code: copy `skills/*` into `.claude/skills/`, adapt `templates/CLAUDE.md` at root.
- Codex: copy `skills/*` into `.agents/skills/`, adapt `templates/AGENTS.md` at root.
- Ordinary web chat: attach skill and policy documents to give context, but uploads alone neither install executable skills nor guarantee compliance.
- Keep approved policies and controls in versioned Git and have AppSec approve project adapters.

## Important deployment restrictions
1. Complete `examples/ADAPTER_TEMPLATE.md` with actual framework/identity provider/DB/hosting.
2. Add live API security integration tests, secret scan, dependency scan, IaC scan and runtime config checks, as applicable.
3. Require product-specific tests on pull requests in branch protection; never interpret the optional job's skip as a green security signal.
4. Confirm the SAST rules cover your chosen languages, and pin actions to reviewed commit SHAs.
5. Record security sign-off, accepted risks, and evidence for each release.

References: https://owasp.org/www-project-application-security-verification-standard/ | https://owasp.org/API-Security/ | https://semgrep.dev/docs/ | https://docs.github.com/en/code-security/
