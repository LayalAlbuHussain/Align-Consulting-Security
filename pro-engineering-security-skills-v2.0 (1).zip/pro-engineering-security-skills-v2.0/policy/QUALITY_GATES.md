# Required quality gates and honest coverage accounting

| Gate | This package (reference) | Required in each product |
|---|---|---|
| Skills pack structure | `python tools/check_framework.py` (frontmatter, names, routing, size limits) | Keep passing when editing skills |
| Multi-platform bundles build | `python tools/build_dist.py` | Rebuild `dist/` after editing skills |
| Reference authorization negative cases | `python -m unittest discover -s tests -v` | Replace/add real HTTP tests (see `examples/ADAPTER_TEMPLATE.md`) |
| Lint / format / type check | Not applicable (no product code) | Mandatory blocking job (ENG-002) |
| Unit + integration tests | Reference tests only | Mandatory blocking job with real test DB (ENG-004) |
| SAST | Semgrep `p/security-audit` in GitHub Actions (needs network) | Confirm language coverage, configure exceptions |
| Secret scanning | Gitleaks job in `security.yml` (full history) | Keep blocking; enable platform push protection |
| Dependency review / SCA | Optional GitHub Dependency Review | Enable or use OSV-Scanner / Trivy / Snyk equivalent |
| Container & IaC scanning | **Not configured** | Trivy/Grype for images; Checkov/Trivy for IaC (SEC-014) |
| Dynamic app tests (DAST) | **Not configured** | AuthN/AuthZ/CSRF/abuse tests + ZAP baseline against a test environment |
| Accessibility checks | **Not configured** | axe/Lighthouse CI for UI projects (ENG-007) |
| Human security sign-off | **Required** for high-risk changes | Record reviewer and evidence |

**Release policy:** A passing framework pipeline is not a release approval. Enforce the product's application-security-tests job and missing scanners through branch protection / rulesets. An optional job's skip is NOT a pass. Never use `continue-on-error` for gates. Pin third-party actions and images to full commit SHAs/digests before enterprise rollout. Classify exceptions with owner, expiration and compensating controls.
