# Engineering Standards — v2.0

Applicability: all software built or changed by the team or by AI assistants on its behalf (web, mobile, backend, data, infrastructure, scripts). Mandatory unless an approved exception exists. Security requirements live in `SECURITY_POLICY.md` and take precedence on conflict.

| ID | Standard | Skill |
|---|---|---|
| ENG-001 | **Definition of Done**: requirement met incl. edge/error cases; tests added; real verification results or explicit "not run"; docs updated; no secrets/debug code; risks stated. | `eng-core-standards` |
| ENG-002 | **Code quality**: intention-revealing names, small single-purpose functions, no swallowed errors, no magic values, linters/formatters/type checks enforced in CI. | `eng-code-quality` |
| ENG-003 | **Design**: modular boundaries, dependencies point inward, one owner per data set, significant decisions recorded as ADRs. | `eng-architecture` |
| ENG-004 | **Testing**: every behavior change has automated tests incl. negative cases; every bug fix has a regression test; tests deterministic; critical journeys covered end-to-end. | `eng-testing` |
| ENG-005 | **Review**: every change to `main` goes through PR review with required checks; findings classified by severity; blockers resolved before merge. | `eng-code-review`, `eng-git-workflow` |
| ENG-006 | **APIs & data**: contract-first APIs (OpenAPI/schema), consistent errors (RFC 9457), pagination, versioning; DB constraints enforce invariants; zero-downtime migrations. | `eng-api-design`, `eng-database` |
| ENG-007 | **Frontend**: WCAG 2.2 AA accessibility, i18n (incl. RTL where relevant), loading/error/empty states, Core Web Vitals targets. | `eng-frontend` |
| ENG-008 | **Operability**: structured logs with trace IDs, RED metrics, tracing, health/readiness endpoints, actionable alerts with runbooks. | `eng-observability` |
| ENG-009 | **Delivery**: build once and promote; IaC for infrastructure; automated rollback path; backups with tested restores. | `eng-devops` |
| ENG-010 | **Documentation**: README with working quick start, configuration reference, runbooks for on-call, docs updated with behavior changes. | `eng-documentation` |
| ENG-011 | **Honesty of AI output**: AI assistants must not fabricate APIs, packages, test results or compliance claims; uncertainty is stated; AI code is reviewed like human code. | `eng-core-standards`, `sec-ai-llm-security` |

Exceptions: documented with owner, reason, expiry date and compensating measure.
