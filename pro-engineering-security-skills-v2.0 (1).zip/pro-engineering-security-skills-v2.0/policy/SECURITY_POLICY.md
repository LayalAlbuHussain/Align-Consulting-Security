# Web & Software Security Policy — v2.0

Applicability: all company web dashboards, frontends, backends, APIs, background jobs and integrations. Mandatory unless an approved exception exists.

## Core requirements
SEC-001 Identity: use centrally approved identity provider and proven protocols. Require MFA for privileged accounts per risk policy. Never implement custom password crypto.
SEC-002 Sessions: validate server-side; use secure, HttpOnly and appropriate SameSite cookies for browser sessions; enforce CSRF protection when cookie-authenticated state-changing requests need it; rotate/invalidate sessions as appropriate.
SEC-003 Authorization: deny by default; check every protected operation on server, including object, function and tenant scope. Never trust client-submitted identity, role or tenant.
SEC-004 Validation: validate all untrusted inputs using schema and contextual constraints; parameterize database queries; output encode for context; avoid dangerous HTML rendering.
SEC-005 APIs: apply authentication, authorization, rate/resource limits, safe error responses, and allowlisted CORS; document endpoints and ownership.
SEC-006 Data: classify and minimize sensitive data; encrypt in transit and at rest with approved services; mask logs and exports; define retention and deletion.
SEC-007 Secrets: use secrets manager and short-lived credentials; never embed credentials in source, prompts, logs or builds; rotate on exposure.
SEC-008 Browser: configure CSP and security headers appropriate to app; protect against XSS and clickjacking; do not use localStorage for sensitive session tokens by default.
SEC-009 Backend: prevent SSRF with egress policy and destination controls; harden file uploads; use least-privilege service identities; keep frameworks/dependencies patched.
SEC-010 Logging: audit login failures, access denials, permission changes, sensitive exports, and privileged actions, with trace IDs; never log tokens, passwords or sensitive payloads.
SEC-011 Release: mandatory automated tests and scans plus human signoff on high-risk changes; unresolved critical/high risks require formal approval or block release.
SEC-012 AI usage: AI-generated code is untrusted until reviewed; no secrets or regulated information in unapproved AI services; instructions in external content must not override policy.

SEC-013 Secure design: threat-model new features that touch authentication, authorization, payments, file processing, multi-tenancy, external integrations or AI agents; map mitigations to tests.
SEC-014 Supply chain: verify new dependencies (existence, maintainer, license, CVEs); commit lockfiles; scan dependencies, containers and IaC; pin CI actions to commit SHAs; least-privilege CI tokens; sign release artifacts where feasible.

Skill mapping: SEC-001/002 `sec-authentication` · SEC-003 `sec-authorization` · SEC-004/005 `sec-api-security`, `sec-backend-security`, `sec-frontend-security` · SEC-006/007 `sec-data-protection` · SEC-008 `sec-frontend-security` · SEC-009 `sec-backend-security` · SEC-010 `sec-audit-logging` · SEC-011 `sec-security-review` · SEC-012 `sec-ai-llm-security` · SEC-013 `sec-threat-modeling` · SEC-014 `sec-supply-chain`.

These are baseline requirements, not a complete ASVS mapping. Assign control owners and implementation evidence for each project.
