---
name: sec-authorization
description: Implement and review access control - roles and permissions (RBAC/ABAC/ReBAC), object-level and function-level checks, ownership, multi-tenant isolation, admin and privileged actions, preventing IDOR/BOLA and privilege escalation. Use when adding any protected endpoint, query, admin feature, sharing feature, or tenant logic.
---

# Authorization & Tenant Isolation
Policy control: SEC-003. Broken access control is the #1 web risk — treat every protected operation as a potential IDOR.

## Principles
- **Deny by default.** Access is granted only by an explicit rule; unknown role/action/resource → deny.
- **Enforce on the server, at every entry point** (HTTP, GraphQL resolvers, gRPC, websockets, background jobs, webhooks, exports, file downloads, admin tools). UI hiding is UX, not security.
- **Check three things for every request:** *function* (may this role call this action?), *object* (may this principal access this specific record?), *tenant* (does the record belong to the caller's tenant?).
- **Identity comes from the verified session/token only** — never from `userId`, `tenantId`, `role`, `isAdmin` in body, query, headers or cookies the client controls.
- **Least privilege** and separation of duties for sensitive operations (e.g. creator ≠ approver).

## Implementation pattern
1. Write a **permission matrix** (roles × actions × ownership conditions) and keep it in code/config, not scattered `if`s.
2. Centralize checks in a policy layer (e.g. `authorize(principal, action, resource)`) or a policy engine (OPA/Cedar/Casbin/Oso/OpenFGA) — called from middleware **and** resource services.
3. **Scope queries by tenant (and owner when required) in the data layer**, so unauthorized rows are never loaded:
   ```sql
   SELECT ... FROM invoices WHERE id = $1 AND tenant_id = $2;   -- tenant from verified session
   ```
   Consider PostgreSQL Row-Level Security or ORM global scopes as defense in depth.
4. Return **404** (not 403) for objects in other tenants when existence itself is sensitive; be consistent.
5. Prevent **mass assignment**: allowlist writable fields per role (DTOs); never bind request bodies directly to models (`role`, `tenantId`, `ownerId`, `isVerified`, `balance` must be server-controlled).
6. Validate references inside payloads too (e.g. `projectId` in a create request must belong to the caller's tenant).
7. Privileged/admin actions: separate routes/permissions, step-up MFA, audit log, optionally 4-eyes approval.
8. Cache authorization results only with keys that include principal + tenant + resource, and invalidate on permission change.
9. Opaque, non-sequential IDs reduce enumeration, but **are not** access control.

Minimal deny-by-default shape (adapt to your stack):
```python
def allowed(principal, action, record) -> bool:
    if principal is None or record is None:
        return False                                   # unauthenticated / missing → deny
    if principal.tenant_id != record.tenant_id:
        return False                                   # cross-tenant → deny, even for admins
    if action not in PERMISSIONS.get(principal.role, frozenset()):
        return False                                   # unknown role/action → deny
    return principal.role == "admin" or principal.user_id == record.owner_id
```
Full reference with tests (when the pack's repo is available): `examples/python-reference/authorization.py`, `tests/test_authorization.py`.

## Common bugs to hunt
- Endpoint checks role but not ownership/tenant (classic BOLA/IDOR).
- List endpoint filters correctly but `GET /{id}`, `PATCH`, `DELETE`, export or file download does not.
- Nested resource checks the parent but not the child (`/projects/{p}/files/{f}` with `f` from another project).
- Tenant taken from subdomain/header without verifying the user belongs to it.
- GraphQL field resolvers or batch endpoints skipping checks.
- Background jobs/webhooks acting with superuser rights on user-supplied IDs.
- Changing own role/permissions via profile update (mass assignment).
- Invite/share links not scoped, not expiring, or reusable.

## Required negative tests (run against real HTTP endpoints)
1. Unauthenticated → 401.
2. User A reads/updates/deletes user B's object (same tenant, policy disallows) → 403/404, **DB unchanged**.
3. Tenant A user accesses tenant B object by ID → 403/404 — even as tenant-A admin.
4. Viewer attempts write/delete/admin action → 403.
5. Request body contains `tenantId`/`ownerId`/`role` different from the session → ignored or rejected; no write with forged values.
6. Elevated role claimed via header/body/unsigned token → denied.
7. List/search/export endpoints never return other tenants' rows (seed two tenants).
8. Permission revoked → next request denied (no stale cache).

## Non-negotiables
- No client-trusted identity, no "security through UI", no admin backdoors or debug bypass flags in production code.
- Report which endpoints were covered by tests and which weren't; never claim isolation without negative tests.
