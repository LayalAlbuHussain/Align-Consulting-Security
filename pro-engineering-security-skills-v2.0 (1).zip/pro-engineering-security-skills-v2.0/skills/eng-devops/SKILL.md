---
name: eng-devops
description: Build and run software reliably - CI/CD pipelines (GitHub Actions, GitLab CI, Azure DevOps, Jenkins), Dockerfiles and containers, Kubernetes manifests, Infrastructure as Code (Terraform/OpenTofu, Pulumi, CloudFormation/Bicep), environment configuration, deployment strategies, rollback and backups. Use when writing pipelines, Dockerfiles, IaC, deployment or environment config. Pair with sec-supply-chain.
---

# DevOps, CI/CD & Infrastructure

## CI pipeline (every PR)
Order fast → slow, fail fast:
1. Install with lockfile (`npm ci`, `pip install -r requirements.lock`/`uv sync --frozen`, `go mod download`), with caching.
2. Format check + lint + type check.
3. Unit tests → integration tests (service containers) with coverage report.
4. Security: SAST, dependency/SCA scan, secret scan, IaC scan, container image scan (see `sec-supply-chain`).
5. Build artifact/image once; tag with commit SHA; generate SBOM.
- Security and test gates **block** merges (branch protection). Never `continue-on-error` on gates; a skipped required job is not a pass.

## CD
- **Build once, promote the same artifact** through dev → staging → prod; only config differs.
- Automated deploy to staging on merge; production via approved promotion (manual approval for high-risk systems).
- Strategies: rolling (default), **blue/green** (instant switch/rollback), **canary** (small % first, watch metrics, auto-rollback), feature flags to decouple deploy from release.
- Database migrations run as a separate, backward-compatible step (expand/contract — see `eng-database`).
- Post-deploy smoke tests and automatic rollback on failed health/SLO checks.

## Containers (Dockerfile)
```dockerfile
# Build stage
FROM node:22-bookworm-slim AS build      # pin version; pin digest in production
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build && npm prune --omit=dev

# Runtime stage
FROM gcr.io/distroless/nodejs22-debian12
WORKDIR /app
COPY --from=build /app/dist ./dist
COPY --from=build /app/node_modules ./node_modules
USER nonroot
EXPOSE 8080
CMD ["dist/server.js"]
```
- Multi-stage; minimal base (distroless/alpine/slim); pinned versions/digests; non-root user; read-only filesystem where possible; `.dockerignore` (exclude `.git`, `.env`, tests, node_modules); no secrets in layers or build args; `HEALTHCHECK` or orchestrator probes; one process per container.

## Kubernetes baseline
Resource requests/limits; liveness/readiness/startup probes; `securityContext` (`runAsNonRoot`, `readOnlyRootFilesystem`, drop all capabilities, no privilege escalation); NetworkPolicies default-deny; secrets from a secret manager (External Secrets/CSI), not plain manifests in Git; PodDisruptionBudgets; HPA; namespaces per environment/team; images by digest.

## Infrastructure as Code
- All infra in code (Terraform/OpenTofu, Pulumi, CloudFormation, Bicep) — no click-ops in production.
- Remote state with locking and encryption; separate state per environment; modules for reuse; pinned provider versions.
- `plan` on PR (reviewed), `apply` from CI after approval. Drift detection.
- Scan IaC (Checkov, tfsec/Trivy, KICS). Least-privilege IAM, encryption at rest, private networking, no `0.0.0.0/0` on admin ports, logging enabled.

## Configuration & secrets (12-factor)
- Config via environment variables / config service; validate at startup and fail fast if missing.
- Commit `.env.example` with placeholders only. Secrets from a secret manager (Vault, AWS/GCP/Azure secret managers), injected at runtime, rotated; CI uses OIDC federation instead of long-lived cloud keys.

## Reliability & operations
- Backups automated, encrypted, off-site/cross-region, and **restore-tested** on a schedule; defined RPO/RTO.
- Observability shipped with the service (see `eng-observability`).
- Environments reproducible; ephemeral preview environments for PRs if feasible.
- Runbooks for deploy, rollback, failover, and incident response.

## Output
Pipeline/Dockerfile/IaC files ready to commit, with comments on anything that must be customized (registry, secrets names, regions), and how to validate (`docker build`, `terraform validate/plan`, `act`/pipeline dry-run).
