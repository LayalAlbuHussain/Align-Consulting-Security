---
name: eng-observability
description: Implement error handling, structured logging, metrics, distributed tracing, health checks and alerting so systems are debuggable and operable in production (OpenTelemetry-friendly). Use when adding error handling, logs, monitoring, dashboards, SLOs, or when a service is hard to debug. Pair with sec-audit-logging for security events.
---

# Error Handling & Observability

## Error handling architecture
- Distinguish **expected errors** (validation, not found, conflict, business rule) from **unexpected errors** (bugs, outages).
  - Expected → typed errors/results, mapped to clear client responses (4xx).
  - Unexpected → propagate to a single top-level handler that logs with full context, returns a generic 500 with a `traceId`, and alerts if rate exceeds threshold.
- Wrap errors with context as they bubble up (`fmt.Errorf("load order %s: %w", id, err)`, `raise X from e`, `new Error(msg, { cause })`).
- Never swallow; never leak internals (stack, SQL, paths, secrets) to clients.
- Resilience: timeouts on every I/O, retries only for transient + idempotent operations (exponential backoff + jitter, max attempts), circuit breakers for flaky dependencies, graceful degradation (serve cached/partial data).
- Graceful shutdown: stop accepting work, finish in-flight requests/jobs, close pools.

## Structured logging
- JSON logs to stdout (let the platform ship them). One event per line.
- Standard fields: `timestamp` (UTC ISO-8601), `level`, `message`, `service`, `env`, `version`, `traceId`, `spanId`, `requestId`, `userId`/`tenantId` (pseudonymous IDs, not emails), `event`/`code`, `durationMs`.
- Levels: `ERROR` needs action; `WARN` unexpected but handled; `INFO` business-relevant lifecycle events; `DEBUG` off in production by default.
- Log messages are constant strings with variables in fields (`"order created"`, `{orderId}`) — searchable and aggregatable.
- **Never log**: passwords, tokens, API keys, session IDs, full card numbers, secrets, full request bodies with PII. Use a redaction filter centrally.
- Sample noisy logs; don't log inside tight loops.

## Metrics
- **RED** for services: Rate, Errors, Duration (histograms, p50/p95/p99) per endpoint.
- **USE** for resources: Utilization, Saturation, Errors (CPU, memory, pool, queue depth).
- Business metrics: signups, orders, payments failed.
- Watch label cardinality — never use user IDs, emails or raw URLs as metric labels.

## Tracing
- Use **OpenTelemetry** SDKs/auto-instrumentation; propagate W3C `traceparent` across HTTP, gRPC and message headers.
- Span around external calls (DB, HTTP, queue) with useful attributes (no secrets/PII).
- Put `traceId` in logs and error responses to correlate.

## Health & readiness
- `/healthz` (liveness: process alive, no dependency checks) and `/readyz` (readiness: can serve — DB/cache reachable). Keep them cheap and unauthenticated but non-sensitive.

## SLOs & alerting
- Define SLIs (availability, latency) and SLOs (e.g. 99.9% of requests < 300 ms over 30 days) for user-facing journeys.
- Alert on **symptoms users feel** (SLO burn rate, error rate, latency), not on every CPU spike. Every alert is actionable and links to a runbook.
- Dashboards per service: RED metrics, saturation, dependency health, recent deploys.

## Output
Error types + global handler, logger configuration with redaction, key metrics/spans to add, health endpoints, and suggested alerts with thresholds and runbook notes.
