---
name: eng-database
description: Design database schemas and write correct, fast, safe queries and migrations for SQL (PostgreSQL, MySQL, SQL Server, SQLite) and NoSQL stores - modeling, constraints, indexing, transactions, isolation, zero-downtime migrations, multi-tenancy and backups. Use when creating tables/collections, writing queries or ORM code, adding migrations, or fixing slow or inconsistent data.
---

# Database Engineering

## Modeling
- Model from access patterns and invariants. Normalize (3NF) by default; denormalize deliberately for measured read needs.
- Every table: primary key (UUID/ULID for distributed/public IDs, bigint identity internally), `created_at`, `updated_at` (UTC, timezone-aware type).
- **Enforce invariants in the database**, not only in code: `NOT NULL`, `UNIQUE`, `CHECK`, foreign keys, enum/check constraints. The DB is the last line of defense against bad data.
- Correct types: `numeric/decimal` for money, `timestamptz` for instants, `boolean` not strings, `jsonb` only for genuinely schemaless data (still validate it).
- Text: UTF-8 everywhere (`utf8mb4` on MySQL) — required for Arabic and emoji. Consider collation for sorting/search.
- Soft delete only if required by the business (and then filter it everywhere, preferably via views/scopes); otherwise hard delete + audit log.
- Multi-tenant: `tenant_id` on every tenant-owned row, part of composite indexes/unique constraints; consider PostgreSQL Row-Level Security as defense in depth (see `sec-authorization`).

## Queries
- **Always parameterized** (bound parameters / ORM query builders). Never concatenate user input into SQL — including `ORDER BY` columns and table names (use allowlists).
- Select explicit columns; avoid `SELECT *` in application code.
- Avoid N+1: joins, `IN` batching, ORM eager loading.
- Paginate with keyset (`WHERE (created_at, id) < ($1, $2) ORDER BY created_at DESC, id DESC LIMIT 50`) for large tables.
- Use `EXPLAIN (ANALYZE)` to verify plans for important queries.

## Indexing
- Index foreign keys and columns used in frequent `WHERE`/`JOIN`/`ORDER BY`.
- Composite index order: equality columns first, then range/sort columns. Leftmost-prefix rule.
- Partial indexes for hot subsets (`WHERE status = 'pending'`), covering indexes (`INCLUDE`) for index-only scans.
- Every index costs writes and storage — remove unused ones (check usage stats).

## Transactions & concurrency
- Wrap multi-step invariants in a transaction; keep transactions short; never call external HTTP inside a DB transaction.
- Know the isolation level (Postgres default READ COMMITTED). Prevent lost updates with optimistic locking (`version` column) or `SELECT ... FOR UPDATE`.
- Use unique constraints + upsert (`INSERT ... ON CONFLICT`) for idempotency instead of check-then-insert races.
- Handle deadlocks/serialization failures with bounded retries.
- Reliable side effects: transactional outbox table, not "commit then publish and hope".

## Migrations (zero-downtime)
- Versioned, reviewed, forward-only migration files in source control (Flyway, Liquibase, Alembic, Prisma, Rails, EF, golang-migrate...). Never edit an applied migration.
- **Expand → migrate → contract**:
  1. Add new column/table (nullable or with default) — old code still works.
  2. Deploy code that writes both / reads new with fallback; backfill in batches.
  3. Switch reads; then remove old column in a later release.
- Avoid long locks: create indexes concurrently (`CREATE INDEX CONCURRENTLY`), add constraints as `NOT VALID` then `VALIDATE`, batch large updates, set `lock_timeout`.
- Every migration has a tested rollback or roll-forward plan; test on a production-sized copy for big tables.

## Operations
- Connection pooling (PgBouncer/HikariCP/etc.) sized to DB limits.
- Least-privilege DB users: app user cannot `DROP`/alter schema; separate migration user; read-only user for analytics.
- Automated backups + **tested restores** (RPO/RTO defined); point-in-time recovery for critical data.
- Encrypt at rest and in transit (TLS); restrict network access to the DB.
- Monitor slow queries, connections, replication lag, disk, bloat.

## NoSQL notes
- Design documents/keys around query patterns (single-table design for DynamoDB; embed vs reference in MongoDB by access and growth).
- Still validate schemas (JSON Schema validators), still enforce tenant scoping in every query, and beware operator injection (`{"$ne": null}`) — validate types before building queries.

## Output
Schema DDL (or model code) with constraints and indexes, migration files following expand/contract, example queries, and the tests/EXPLAIN checks to run.
