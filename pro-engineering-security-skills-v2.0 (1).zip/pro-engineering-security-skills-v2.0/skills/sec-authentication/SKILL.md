---
name: sec-authentication
description: Secure authentication and session management - login, logout, passwords, MFA/passkeys, OAuth 2.x/OIDC/SAML integration, JWT and refresh tokens, cookies, session lifetime, password reset, account recovery and brute-force protection. Use when building or reviewing any sign-in, identity provider integration, token or session code.
---

# Authentication & Sessions
Policy controls: SEC-001, SEC-002 (see `policy/SECURITY_POLICY.md` if present; otherwise this skill is the baseline).

## Decide the approach
1. **Prefer a proven identity provider** (company IdP / Entra ID / Okta / Auth0 / Keycloak / Cognito / Firebase Auth) via **OIDC Authorization Code + PKCE**. Do not invent auth protocols or crypto.
2. Browser apps: server-side sessions or the **BFF pattern** (backend holds tokens, browser gets an `HttpOnly` session cookie). Avoid keeping access/refresh tokens in `localStorage`/`sessionStorage`.
3. Machine-to-machine: OAuth client credentials or workload identity (mTLS/OIDC federation), short-lived tokens, scoped per service.
4. Never use the OAuth implicit flow or Resource Owner Password flow for new work.

## Passwords (only if you must store them)
- Hash with **Argon2id** (OWASP baseline: m=19 MiB, t=2, p=1) or bcrypt (cost ≥ 10, mind its 72-byte limit) or scrypt — via a maintained library. Never MD5/SHA-x alone, never reversible encryption.
- Length over complexity (NIST SP 800-63B): minimum 8 chars when MFA is used, 15 when the password is the only factor; allow at least 64; accept all printable Unicode and spaces; no forced periodic rotation; no composition rules; **block breached/common passwords** (e.g. k-anonymity check against a breach corpus).
- Constant-time comparison; generic error messages ("Invalid email or password") to avoid account enumeration — same for signup and reset flows (respond identically).

## Brute force & abuse
- Rate-limit by account **and** by IP/device; progressive delays or temporary lockout with notification; CAPTCHA/bot protection after failures on public forms.
- Alert on credential stuffing patterns (many accounts, one IP; many IPs, one account).

## MFA
- Required for admins/privileged roles and sensitive actions (per risk policy). Prefer **passkeys/WebAuthn (phishing-resistant)** → TOTP → push with number matching. SMS/email OTP only as a fallback.
- Re-authenticate (step-up) before changing email/password/MFA, viewing secrets, payouts, or deleting accounts.
- Recovery codes: single-use, hashed at rest.

## Sessions & cookies
- Session ID: ≥ 128 bits from a CSPRNG; **regenerate on login and privilege change**; invalidate server-side on logout, password change, MFA reset, and admin revocation.
- Cookie: `__Host-` prefix, `Secure`, `HttpOnly`, `SameSite=Lax` (or `Strict`), `Path=/`, no `Domain`.
- Timeouts: idle (e.g. 15–30 min for sensitive apps) and absolute (e.g. 8–12 h); allow users to see and revoke active sessions.
- CSRF: cookie-authenticated state-changing requests need protection — SameSite plus a synchronizer/double-submit token or verified `Origin`/`Sec-Fetch-Site` header checks. Never change state on `GET`.

## Tokens (JWT / OAuth)
- Validate **signature with an algorithm allowlist** (reject `alg: none`, prevent RS/HS confusion), `iss`, `aud`, `exp`, `nbf`, and `iat` skew; fetch keys from the IdP JWKS with caching and rotation.
- Access tokens short-lived (5–15 min); refresh tokens rotated on every use with **reuse detection** (revoke the family on reuse), bound to client, revocable.
- Don't put sensitive data in JWT payloads (they are only base64-encoded). Don't accept tokens from query strings (they leak in logs/referrers).
- Derive user, tenant and roles **only from verified token claims or the server session** — never from request body/headers the client controls.

## Password reset & account recovery
- Reset tokens: CSPRNG, single-use, short TTL (≤ 30–60 min), stored hashed, bound to the user; invalidate on use and on password change.
- After reset: revoke all sessions, notify the user, don't auto-login without MFA.
- Changing email: confirm via both old and new address for sensitive accounts.

## Required negative tests
- Missing/invalid/expired/revoked credentials → 401; tampered JWT signature, `alg:none`, wrong `aud`/`iss` → 401.
- Session fixation: session ID changes after login; old ID unusable after logout.
- Login and reset responses identical for existing vs non-existing accounts (body and approximate timing).
- Rate limit triggers after N failed attempts; reset token reuse fails; refresh token reuse revokes the session family.
- State-changing request without CSRF protection (cookie auth) → rejected.

## Non-negotiables
- No custom crypto, no plaintext or reversible passwords, no secrets/tokens in logs, URLs, source or client bundles.
- Never trust client-supplied identity, role or tenant. Never claim the flow is secure without tests or evidence; report what was and wasn't verified.
