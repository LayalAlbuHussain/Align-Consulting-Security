---
name: sec-data-protection
description: Protect sensitive and personal data and secrets - data classification, minimization, encryption in transit and at rest, field-level encryption, tokenization, masking, exports, retention and deletion, privacy requirements (e.g. Saudi PDPL, GDPR), and secrets management and rotation. Use when handling PII, financial/health data, credentials, API keys, database storage, backups, exports or analytics.
---

# Data Protection & Secrets
Policy controls: SEC-006, SEC-007.

## 1. Classify every field you touch
| Class | Examples | Minimum handling |
|---|---|---|
| Public | Marketing content | Integrity only |
| Internal | Non-sensitive business data | Auth required |
| Confidential | Names, emails, phone, addresses, contracts | Need-to-know access, encrypted at rest, masked in logs |
| Restricted | National ID / Iqama numbers, passwords, payment cards, health, biometrics, precise location, secrets/keys | Strong access control, field-level encryption or tokenization, audited access, strict retention |

Produce a short data inventory for the feature: field → class → purpose → where stored → who can access → retention.

## 2. Minimize
- Collect only what the purpose needs; don't store what you can derive or fetch on demand.
- Avoid copying sensitive data into caches, search indexes, analytics, error trackers, AI prompts, or test fixtures. Use synthetic/anonymized data outside production.
- Return only needed fields in APIs; mask where full values aren't needed (`****1234`, `a***@example.com`).

## 3. Encrypt
- **In transit:** TLS 1.2+ (prefer 1.3) everywhere, including internal service-to-service and DB connections; HSTS for web.
- **At rest:** storage/DB/backup encryption with a managed KMS (envelope encryption, key rotation, access logged).
- **Field-level:** encrypt Restricted fields in the application (AEAD, e.g. AES-256-GCM via a vetted library/KMS SDK) so DB admins and dumps don't expose them. For exact-match lookup, store a keyed hash (HMAC) alongside.
- **Payment cards:** don't store PAN at all — use a PCI-compliant provider's tokenization.
- Passwords are hashed, not encrypted (see `sec-authentication`).

## 4. Exports, reports & downloads
Authorize by role + tenant; limit rows; audit (who, what filter, how many rows); expire download links; watermark if needed; protect CSV exports against **formula injection** (prefix cells starting with `=`, `+`, `-`, `@`, tab, CR with `'`).

## 5. Retention & deletion
- Define retention per data class and legal basis; automate deletion/anonymization jobs; include backups and replicas in the plan (crypto-shredding where practical).
- Support data subject requests (access, correction, deletion) if privacy law applies.

## 6. Privacy & compliance (confirm with legal/compliance)
- Saudi Arabia: Personal Data Protection Law (PDPL, SDAIA) — lawful basis/consent, purpose limitation, cross-border transfer rules, breach notification; NCA controls (e.g. ECC) for regulated entities.
- EU users: GDPR. Payments: PCI DSS. Health: applicable health-data rules.
- Record processing purposes; privacy by design and by default; privacy notice updates for new data uses.

## 7. Secrets management
- Secrets live in a **secret manager** (Vault, AWS Secrets Manager/SSM, GCP Secret Manager, Azure Key Vault, Doppler, 1Password, Kubernetes External Secrets) — never in source, images, `.env` committed files, CI logs, tickets, chat, or AI prompts.
- Prefer **short-lived, scoped credentials**: OIDC federation from CI to cloud, workload identity, dynamic DB credentials.
- One secret per service per environment; least privilege; owner and expiry recorded.
- Rotation: scheduled, automated where possible, and **immediate on suspected exposure** (rotate first, then investigate and clean history).
- Detection: pre-commit and CI secret scanning (gitleaks/trufflehog/GitHub secret scanning with push protection), including history.
- App startup validates required secrets exist; error messages never print secret values.

## Required checks/tests
- Sensitive fields absent from API responses for unauthorized roles and from logs (log-capture test).
- Export endpoint enforces role + tenant and writes an audit event.
- Encrypted fields unreadable in raw DB rows; decryption only via the service.
- Secret scan clean on the branch and history; no secrets in build artifacts.
- Retention job deletes/anonymizes records past retention (test with fixed clock).

## Non-negotiables
No secrets or personal data in source, logs, prompts or client bundles; no claims of compliance with any law/standard without evidence and the compliance owner's sign-off.
