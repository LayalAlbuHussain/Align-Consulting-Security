---
name: eng-code-review
description: Review code changes, pull requests, diffs or snippets like a senior engineer - correctness, design, readability, tests, performance, security and operability - and produce prioritized, actionable findings. Use when asked to review, audit, critique, "check my code", or before merging.
---

# Code Review

## Process
1. **Understand intent**: what problem does the change solve? Read the description, linked issue, and tests first.
2. **Big picture**: Is this the right approach? Right place? Scope appropriate? Anything missing (migrations, docs, config, feature flag)?
3. **Line-by-line** using the checklist below.
4. **Run it** if you can (build, tests, linters). Otherwise mark findings as from static reading.
5. **Report** with severity, evidence, and a concrete fix.

## Checklist
**Correctness** — logic matches requirements; edge cases (null/empty/limits); error paths; off-by-one; integer overflow; float money; timezone; concurrency/races; idempotency; resource leaks; transaction boundaries.

**Security** (apply `sec-security-review` for anything sensitive) — input validation; injection (SQL/NoSQL/command/template/path); authN + server-side authZ including object/tenant scope; secrets in code/logs; XSS/unsafe HTML; SSRF; unsafe deserialization; crypto misuse; sensitive data exposure.

**Design** — single responsibility; coupling; follows existing architecture and patterns; no premature abstraction; public API surface minimal and consistent; backward compatibility.

**Readability** — naming; function size; nesting; comments explain why; dead code; consistent style (linter-enforced, don't nitpick what a formatter fixes).

**Tests** — new behavior tested; negative cases; regression test for bug fixes; tests are deterministic and meaningful (would fail if the code were wrong).

**Performance** — N+1 queries; unbounded loops/lists/memory; missing pagination or indexes; blocking I/O in async paths; needless work in hot paths.

**Operability** — logs/metrics for new flows; error messages actionable; config documented; safe migrations; rollback path; feature flags for risky changes.

## Severity scale
| Level | Meaning | Merge? |
|---|---|---|
| 🔴 Blocker | Bug, security hole, data loss, broken build/contract | Must fix |
| 🟠 Major | Likely bug, missing tests for critical path, significant design issue | Should fix before merge |
| 🟡 Minor | Readability, small design improvement | Fix or justify |
| 🔵 Nit / suggestion | Style preference, optional idea | Author's choice |
| ✅ Praise | Something done well (be specific) | — |

## Finding format
```
[🔴 Blocker] src/orders/service.ts:42 — Order lookup ignores tenant
Evidence: `findById(id)` does not filter by `ctx.tenantId`; any user can read another tenant's order by ID.
Fix: use `findByIdAndTenant(id, ctx.tenantId)` and return 404 when null. Add test `returns_404_for_other_tenant_order`.
```

## Tone
- Critique the code, not the person. Ask questions when intent is unclear ("Is X intended when Y?").
- Explain *why*, link to standard/docs when useful, and propose the fix.
- Don't block on personal preference; mark it as a nit.

## Output
1. Verdict: **Approve / Approve with comments / Request changes** + one-line rationale.
2. Findings table sorted by severity.
3. What was verified (ran tests? which?) vs. static-only.
4. Optional: suggested follow-ups outside this PR's scope.
