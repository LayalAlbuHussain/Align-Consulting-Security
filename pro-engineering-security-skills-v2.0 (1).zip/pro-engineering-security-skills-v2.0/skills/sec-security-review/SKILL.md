---
name: sec-security-review
description: Perform a structured security review of code, pull requests, features or whole applications before merge or release - map the attack surface, check against OWASP Top 10 categories and the security policy, rate findings by severity with evidence and fixes, and decide block/approve. Use when asked for a security review, audit, pentest-style code review, release readiness, or "is this secure?".
---

# Security Review
Policy controls: SEC-001 … SEC-012 (`policy/SECURITY_POLICY.md` if present; otherwise use the `sec-*` skills as the baseline).

## Process
1. **Scope**: what changed / what's in scope; deployment context (internet-facing? multi-tenant? regulated data?).
2. **Attack surface**: entry points (routes, resolvers, jobs, webhooks, file inputs, CLI), actors and roles, trust boundaries, sensitive data, external dependencies. For new features, do a quick `sec-threat-modeling` pass.
3. **Review** with the checklist below, tracing untrusted input from source to sink and checking authorization on every path.
4. **Verify** with tools if you can run them (SAST e.g. Semgrep/CodeQL, SCA, secret scan, tests, DAST e.g. ZAP baseline). Never claim a tool ran without its output.
5. **Report** findings with severity, evidence (file:line, request/response), impact, and a concrete fix + test.
6. **Decision**: block release on unresolved Critical/High unless a formal, time-bound risk acceptance exists (owner, expiry, compensating controls).

## Checklist (OWASP Top 10 categories + policy)
- **Broken access control** — every endpoint/resolver/job checks function + object + tenant; no IDOR; no mass assignment; deny by default (`sec-authorization`).
- **Authentication failures** — IdP/OIDC usage, sessions, JWT validation, MFA for admins, reset flows, brute-force limits (`sec-authentication`).
- **Injection** — SQL/NoSQL/command/template/LDAP/XSS; parameterization and output encoding (`sec-backend-security`, `sec-frontend-security`).
- **Cryptographic failures** — TLS, at-rest encryption, password hashing, randomness, no homemade crypto, no disabled cert checks (`sec-data-protection`).
- **Insecure design** — missing rate limits on business flows, trust in client calculations, missing step-up for sensitive actions (`sec-threat-modeling`).
- **Security misconfiguration** — debug off, headers/CSP, CORS allowlist, default creds, verbose errors, open storage buckets, IaC findings.
- **Vulnerable/outdated components & supply chain** — known CVEs, unpinned actions, typosquats, unreviewed new dependencies (`sec-supply-chain`).
- **Software & data integrity** — unsigned updates/artifacts, unsafe deserialization, CI injection, webhook signatures.
- **Logging & alerting failures** — audit events for auth/admin/exports, no secrets in logs (`sec-audit-logging`).
- **SSRF** — outbound fetches of user-influenced URLs (`sec-backend-security`).
- **Exceptional conditions** — fail closed on errors; no auth bypass when a dependency times out; resource exhaustion.
- **Secrets** — none in code, configs, history, bundles, logs, prompts.
- **AI/LLM features** — prompt injection, excessive agency, output handling (`sec-ai-llm-security`).

## Severity
| Severity | Typical examples |
|---|---|
| Critical | Unauthenticated RCE, auth bypass, cross-tenant data access at scale, leaked production secrets |
| High | IDOR on sensitive data, stored XSS in admin area, SQLi behind auth, SSRF to metadata, privilege escalation |
| Medium | Reflected XSS with constraints, missing rate limits on login, verbose errors leaking internals, weak session timeouts |
| Low | Missing hardening header with low impact, minor info disclosure |
| Info | Best-practice suggestions, defense-in-depth ideas |
Adjust by exploitability, exposure (internet vs internal) and data sensitivity; explain the rating.

## Finding format
```
[HIGH] SEC-003 · GET /api/v1/invoices/{id} — cross-tenant read (BOLA)
Evidence: invoices/service.py:88 `Invoice.get(id)` has no tenant filter; tenant comes only from the session in list endpoint.
Impact: any authenticated user can read any tenant's invoices by ID.
Fix: query with `tenant_id = principal.tenant_id`; return 404 otherwise.
Test: `test_get_invoice_other_tenant_returns_404` (asserts 404 and no data in body).
```

## Report template
1. Scope & context · 2. Summary verdict (**Block / Approve with conditions / Approve**) · 3. Findings table (severity, control ID, location, status) · 4. Details per finding · 5. Verification evidence (tools/tests run + results; or "not run") · 6. Residual risks & required approvals.

## Non-negotiables
Evidence-based findings only (no invented vulnerabilities, no invented "all clear"); clearly separate verified facts from suspicions; this review does not replace human AppSec sign-off for high-risk changes.
