---
name: eng-performance
description: Diagnose and improve performance and scalability - latency, throughput, memory, CPU, database queries, caching, concurrency, and frontend load speed (Core Web Vitals). Use when something is slow, times out, uses too much memory, must handle more load, or when asked to optimize.
---

# Performance & Scalability

## Golden rules
1. **Measure first.** No optimization without a baseline number and a profile showing where time/memory goes.
2. **Define the target**: e.g. "p95 < 200 ms at 500 rps", "LCP < 2.5 s on mid-range mobile", "batch finishes in < 10 min".
3. **Fix the biggest bottleneck**, re-measure, repeat. Stop when the target is met.
4. Prefer algorithmic and I/O wins over micro-optimizations. Keep the code readable; comment any non-obvious optimization with its measured gain.

## Workflow
1. Reproduce the slowness with realistic data volume.
2. Profile: CPU profiler (py-spy, cProfile, `pprof`, async-profiler, Chrome Performance), memory profiler, DB `EXPLAIN (ANALYZE, BUFFERS)`, APM traces.
3. Classify: CPU-bound, I/O-bound (DB, network, disk), memory/GC, lock contention, or frontend rendering/network.
4. Apply the matching fix below; re-measure; add a benchmark or performance test to prevent regression.

## Backend & data fixes (most common first)
- **N+1 queries** → eager loading/joins/batching (`IN (...)`, DataLoader).
- **Missing indexes** → index columns used in `WHERE`, `JOIN`, `ORDER BY`; composite index column order matters; verify with `EXPLAIN`.
- **Fetching too much** → select needed columns only; paginate (keyset/cursor for large tables); stream large results.
- **Chatty network** → batch requests, connection pooling, keep-alive, HTTP/2, compression.
- **Repeated expensive work** → cache (in-process LRU, Redis, HTTP cache headers, CDN) with explicit TTL, invalidation, stampede protection, and per-tenant keys.
- **Blocking work in request path** → move to background job/queue; return 202.
- **Serial independent I/O** → run concurrently (`asyncio.gather`, `Promise.all`, goroutines) with a concurrency limit.
- **Wrong complexity** → replace O(n²) loops with hash maps/sets, sort once, precompute.
- **Memory** → stream instead of loading whole files; avoid unbounded caches/queues; release references; watch for leaks (listeners, globals, closures).
- **Locks/contention** → shorter transactions, row-level locking, optimistic concurrency, avoid hot rows.

## Frontend fixes
- Core Web Vitals targets: **LCP < 2.5 s, INP < 200 ms, CLS < 0.1**.
- Ship less JS: code-splitting/lazy routes, tree-shaking, remove heavy deps, analyze bundle.
- Images: modern formats (AVIF/WebP), correct sizes (`srcset`), lazy-load below the fold, explicit width/height.
- Cache static assets with content hashes + long `Cache-Control`; use a CDN.
- Avoid unnecessary re-renders (memoization where measured, stable keys, virtualized long lists).
- Prefetch critical data; avoid request waterfalls; show skeletons for perceived performance.

## Capacity & resilience
- Load test (k6, Locust, JMeter, Gatling) with realistic traffic shapes before launches.
- Timeouts on every outbound call; retries with exponential backoff + jitter, only for idempotent operations.
- Rate limiting and backpressure; autoscaling based on meaningful metrics.
- Set resource limits (memory/CPU) and payload/page-size limits — they are also DoS protection.

## Output
Baseline measurement → identified bottleneck (evidence) → change → new measurement (or "expected; not measured") → trade-offs (complexity, staleness, cost).
