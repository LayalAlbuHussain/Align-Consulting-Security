---
name: eng-testing
description: Design and write effective automated tests - unit, integration, end-to-end, contract, property-based and security negative tests - in any language. Use when adding features, fixing bugs (regression test first), raising coverage, fixing flaky tests, choosing a test strategy, or when asked to "add tests".
---

# Testing

## Strategy
- **Test pyramid / trophy:** many fast unit tests for logic, a solid layer of integration tests for real boundaries (DB, HTTP, queue), few E2E tests for critical user journeys.
- Test **behavior through public interfaces**, not private implementation details. Refactors should not break tests.
- Every bug fix starts with a **failing regression test** that reproduces it.
- Every feature gets: happy path + edge cases + error paths + (if protected) **authorization negative tests**.

## What to test (checklist)
- Boundaries: empty, one, many, max, max+1, zero, negative, very large.
- Inputs: null/undefined/missing, wrong type, malformed, unicode/RTL/emoji, whitespace, very long strings.
- Time: timezones, DST, leap years, month ends, clock skew (inject the clock).
- Concurrency: double submit, race between two writers, retries/idempotency.
- Failures: dependency timeout, 5xx, partial write, disk full, invalid config.
- Security: unauthenticated (401), wrong role/tenant/owner (403/404), injection payloads rejected, oversize payload (413), sensitive fields absent from responses.

## Writing good tests
- Structure **Arrange–Act–Assert** (Given–When–Then). One behavior per test.
- Names describe behavior: `rejects_transfer_when_balance_insufficient`, `returns_404_for_other_tenants_record`.
- Deterministic: no real time, randomness, network, or ordering dependence. Seed randomness; freeze clocks.
- Independent: each test sets up its own data; no shared mutable state; any order, in parallel.
- Use builders/factories for test data with sensible defaults; override only what matters to the test.
- Assert on outcomes that matter (returned value, persisted state, emitted event, HTTP status + body), not on incidental details.
- For denied operations, **also assert no side effect happened** (DB unchanged, no event emitted).

## Test doubles
- Prefer real implementations or in-memory fakes; mock only at architectural boundaries you own the interface of (ports).
- Don't mock what you don't own — wrap third-party SDKs in an adapter and mock the adapter, or use a sandbox/test container.
- Over-mocking = tests that pass while production fails. If a test needs 6 mocks, the design needs work.

## Integration & E2E
- Use real dependencies in containers (e.g. Testcontainers) or ephemeral environments; run migrations as in production.
- Contract tests (e.g. Pact, schema validation against OpenAPI) between services you don't deploy together.
- E2E: only critical journeys (signup, login, checkout); stable selectors (`data-testid`, roles), no sleeps — wait for conditions.

## Advanced techniques (when valuable)
- **Property-based testing** (Hypothesis, fast-check, jqwik) for parsers, serializers, math, invariants (`decode(encode(x)) == x`).
- **Mutation testing** (Stryker, mutmut, PIT) to check that tests actually detect bugs.
- **Snapshot tests** sparingly; review snapshot diffs like code.
- **Fuzzing** for parsers and anything consuming untrusted bytes.

## Coverage
- Coverage is a flashlight, not a target. Aim high on domain logic and security-critical code; don't chase 100% on glue.
- Fail CI on coverage drop for critical modules rather than a global vanity number.

## Flaky tests
Find the cause, don't add retries: shared state, time, ordering, async waits, network, resource leaks, test pollution. Quarantine with an issue link only as a temporary measure.

## Example (pytest)
```python
def test_viewer_cannot_delete_record(client, db, make_user, make_record):
    viewer = make_user(role="viewer", tenant="t1")
    record = make_record(tenant="t1")
    resp = client.delete(f"/api/records/{record.id}", headers=auth(viewer))
    assert resp.status_code == 403
    assert db.records.get(record.id) is not None   # no side effect
```

## Output
Provide tests runnable with the project's existing framework, the command to run them, and real results — or "not run".
