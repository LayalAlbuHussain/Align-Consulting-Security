---
name: eng-api-design
description: Design consistent, evolvable HTTP/REST, GraphQL, gRPC and webhook APIs - resource naming, methods, status codes, error format, pagination, filtering, versioning, idempotency and OpenAPI contracts. Use when creating or changing endpoints, writing an API spec, or integrating clients. Pair with sec-api-security.
---

# API Design

## Contract first
- Write/update the **OpenAPI (or GraphQL schema / .proto)** before or with the code. The spec is the source of truth for docs, client generation, and contract tests.
- Each endpoint documents: purpose, auth requirement, required permission, request/response schemas, error codes, rate limit, idempotency, examples.

## REST conventions
- Resources are nouns, plural, kebab-case: `/v1/invoices`, `/v1/invoices/{invoiceId}/line-items`. Max ~2 levels of nesting.
- Methods: `GET` read (safe), `POST` create/action, `PUT` full replace (idempotent), `PATCH` partial update, `DELETE` remove (idempotent).
- Non-CRUD actions: sub-resource verbs sparingly, e.g. `POST /v1/invoices/{id}/send`.
- JSON field casing: pick one (camelCase or snake_case) and use it everywhere.
- Timestamps ISO-8601 UTC (`2026-01-31T09:30:00Z`); money as `{ "amount": "12.50", "currency": "SAR" }` or integer minor units; IDs as opaque strings (UUID/ULID), never sequential if enumeration matters.

## Status codes
| Code | Use |
|---|---|
| 200 / 201 (+`Location`) / 204 | Success / created / no content |
| 202 | Accepted for async processing (return a status URL) |
| 400 | Malformed request / validation failed |
| 401 | Not authenticated |
| 403 | Authenticated but not allowed (or 404 to avoid revealing existence) |
| 404 | Not found (or not visible to caller) |
| 409 | Conflict (duplicate, version mismatch) |
| 412 | Precondition failed (`If-Match` ETag mismatch) |
| 413 / 415 | Payload too large / unsupported media type |
| 422 | Semantically invalid (if your convention separates it from 400) |
| 429 | Rate limited (+`Retry-After`) |
| 500 / 503 | Unexpected error (no internals leaked) / temporarily unavailable |

## Error format (RFC 9457 Problem Details)
```json
{
  "type": "https://api.example.com/errors/validation",
  "title": "Validation failed",
  "status": 400,
  "detail": "One or more fields are invalid.",
  "instance": "/v1/orders",
  "traceId": "4bf92f3577b34da6",
  "errors": [{ "field": "email", "code": "invalid_format", "message": "Must be a valid email." }]
}
```
Stable machine-readable `code`s; human messages may be localized; never include stack traces, SQL, or internal hostnames.

## Collections
- Always paginate. Prefer **cursor/keyset** pagination (`?limit=50&cursor=...` → `nextCursor`) for large or changing data; offset is acceptable for small admin lists. Enforce a max `limit`.
- Filtering `?status=paid&createdAfter=...`; sorting `?sort=-createdAt` with an allowlist of sortable fields.
- Sparse fields (`?fields=`) and expansion (`?expand=customer`) only with allowlists.

## Reliability
- **Idempotency keys** (`Idempotency-Key` header) for POSTs that create money movements, orders, messages; store key → response for a retention window.
- **Optimistic concurrency** with `ETag` + `If-Match` on updates to prevent lost updates.
- Long-running work → `202` + job resource (`GET /v1/jobs/{id}`).
- Webhooks: signed payloads (HMAC + timestamp), retries with backoff, idempotent consumers, event `id` and `type`, versioned schemas.

## Versioning & evolution
- Version in the path (`/v1`) or header — pick one. Additive changes (new optional fields, new endpoints) are non-breaking; clients must ignore unknown fields.
- Breaking changes (remove/rename field, change type/semantics, new required input) need a new version + deprecation period (`Deprecation` / `Sunset` headers, changelog).

## GraphQL specifics
- Schema-first; nullable by default thoughtfully; `Connection` pagination; input types for mutations; mutation payloads include `userErrors`.
- Protect with depth/complexity limits, persisted queries for public clients, field-level authorization, DataLoader against N+1, and disable introspection in production if the API is private.

## gRPC specifics
- Never reuse or renumber proto field numbers; `reserved` removed ones. Use deadlines on every call and standard status codes.

## Output
Endpoint table (method, path, auth/permission, request, responses), OpenAPI snippet, example requests/responses, and the negative cases to test (401/403/404/400/409/429).
