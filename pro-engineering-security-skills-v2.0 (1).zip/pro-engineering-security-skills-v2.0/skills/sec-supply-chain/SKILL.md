---
name: sec-supply-chain
description: Secure the software supply chain - choosing and adding dependencies, lockfiles and pinning, vulnerability (SCA) and license scanning, typosquatting and AI-hallucinated packages, SBOMs, artifact signing and provenance, and hardening CI/CD pipelines such as GitHub Actions. Use when adding or updating packages, writing CI workflows, building containers, or releasing artifacts.
---

# Software Supply Chain Security
Policy controls: SEC-009, SEC-011.

## Adding a dependency
Before `install`, check:
- [ ] Is it really needed? (stdlib or an existing dependency may suffice; small utilities can be written in-house)
- [ ] **The package exists and is the intended one** — exact name, publisher, repository link. AI assistants sometimes invent plausible package names ("slopsquatting"); attackers register them. Verify on the official registry page.
- [ ] Maintained (recent releases, responsive issues), adequately used, no open critical CVEs, not deprecated.
- [ ] License compatible with company policy (e.g. watch AGPL/GPL for proprietary distribution).
- [ ] Reasonable transitive dependency footprint; no suspicious install scripts.
Explain the choice in the PR.

## Pinning & integrity
- Commit lockfiles (`package-lock.json`/`pnpm-lock.yaml`/`yarn.lock`, `poetry.lock`/`uv.lock`/hashed `requirements.txt`, `go.sum`, `Cargo.lock`, `composer.lock`, `Gemfile.lock`). Install in CI with frozen lockfiles (`npm ci`, `pnpm install --frozen-lockfile`, `pip install --require-hashes`, `uv sync --frozen`).
- Container base images pinned by **digest** in production.
- Private packages: scope/namespace them and configure registries to prevent **dependency confusion** (internal names resolving from public registries).
- Consider disabling install scripts where feasible (`npm ci --ignore-scripts`) and allowlisting the ones you need.

## Continuous scanning
- SCA in CI and scheduled: Dependabot/Renovate (automated update PRs), OSV-Scanner, `npm audit`, `pip-audit`, `govulncheck`, Trivy/Grype for images. Fail on High/Critical with a documented exception process (owner + expiry).
- Secret scanning (gitleaks/trufflehog/platform push protection) on commits and history.
- SAST (Semgrep/CodeQL) with rules covering the project's languages; IaC scanning (Checkov/Trivy).
- Generate an **SBOM** (CycloneDX or SPDX via Syft/Trivy/cdxgen) per release artifact and keep it.

## CI/CD hardening (GitHub Actions examples; apply equivalents elsewhere)
- Top-level `permissions: contents: read`; grant more per job only as needed.
- **Pin third-party actions to full commit SHA** (with a version comment), not tags: `uses: actions/checkout@<40-char-sha> # v4.x`.
- Avoid `pull_request_target` with checkout of PR code; never run untrusted PR code with secrets.
- Prevent **script injection**: don't interpolate `${{ github.event.* }}` (titles, branch names, comments) directly into `run:`; pass via `env:` and quote.
- Use **OIDC** to cloud providers instead of long-lived keys; scope trust policies to repo + branch/environment.
- Protected environments with required reviewers for production deploys; secrets scoped to environments.
- Self-hosted runners: ephemeral, isolated, never for public-repo PRs.
- Security gates are required checks; no `continue-on-error`; a skipped job is not a pass.

## Build integrity & provenance
- Build once in CI (not on laptops); reproducible where feasible.
- Sign artifacts/images (Sigstore cosign) and generate provenance attestations (SLSA level appropriate to risk); verify signatures at deploy (admission policy).
- Restrict who can publish packages/images; MFA on registry accounts; scoped publish tokens.

## Updating
- Small, frequent updates beat rare big-bang upgrades. Read changelogs for major versions; run full tests; watch for maintainer changes or suspicious new install scripts in updates.

## Output
For a new dependency: justification + verification notes + exact install command. For CI: hardened workflow YAML with SHAs marked `<pin-to-sha>` if you cannot look them up — never invent SHAs.
