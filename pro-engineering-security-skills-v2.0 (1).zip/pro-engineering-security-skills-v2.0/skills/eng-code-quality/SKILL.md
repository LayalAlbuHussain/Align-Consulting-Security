---
name: eng-code-quality
description: Write and improve clean, readable, maintainable code in any language. Use when writing new functions/classes/modules, when asked to clean up, simplify or "make it professional", or when code has poor naming, long functions, duplication, deep nesting, magic values, or unclear error handling.
---

# Code Quality

Goal: code that a new teammate can read, change and trust within minutes.

## Naming
- Names reveal intent: `overdueInvoices`, not `list2`; `isEligibleForRefund()`, not `check()`.
- Functions = verbs (`calculateTax`), booleans = predicates (`isActive`, `hasAccess`, `canRetry`), collections = plurals.
- Units in names when ambiguous: `timeoutMs`, `sizeBytes`, `priceCents`.
- No abbreviations except universal ones (`id`, `url`, `http`). No Hungarian notation. No misleading names (`userList` that is a map).
- Follow the language's casing convention (snake_case in Python/Rust, camelCase in JS/Java/Go locals, PascalCase types).

## Functions
- One responsibility, one level of abstraction. If you need "and" to describe it, split it.
- Prefer < ~30 lines and ≤ 3–4 parameters; group related params into an object/struct.
- **Guard clauses** over nested `if`s; return early on invalid states.
- No boolean "mode" flags that switch behavior (`save(user, true)`) — create two named functions.
- Pure where possible: compute in pure functions, perform I/O at the edges.
- Command–query separation: a function either changes state or returns data, not both (unless idiomatic, e.g. `pop`).

## Structure
- High cohesion, low coupling: things that change together live together.
- Depend on abstractions at boundaries (I/O, network, clock, randomness) so they can be faked in tests.
- Composition over inheritance; inheritance only for true "is-a" with shared invariants.
- Keep files focused; split when a file mixes unrelated concerns, not by arbitrary line counts.
- DRY applies to **knowledge**, not to coincidentally similar lines. Rule of three before abstracting.

## Values and types
- No magic numbers/strings: named constants or enums (`MAX_LOGIN_ATTEMPTS = 5`).
- Make illegal states unrepresentable: enums/union types instead of free strings; value objects (`Email`, `Money`) instead of primitives for domain concepts.
- Use the type system fully (TypeScript `strict`, Python type hints + mypy/pyright, Java nullability annotations).
- Avoid `null` as a signal when the language offers `Optional`/`Result`/`Maybe`.
- Money: integer minor units or decimal types — never binary floats.
- Time: store UTC, use timezone-aware types, convert only at display.

## Errors
- Fail fast on programmer errors; handle expected failures explicitly.
- Never swallow exceptions (`catch {}`, `except: pass`). Either handle, wrap with context, or propagate.
- Throw/return specific error types; include context (ids, operation) but **no secrets or PII**.
- Clean up resources deterministically (`with`, `using`, `try-with-resources`, `defer`).

## Comments
- Code explains **what/how**; comments explain **why** (business rule, workaround, non-obvious constraint, link to issue).
- Delete commented-out code — Git remembers.
- Public APIs get doc comments (purpose, params, return, errors, example).
- `TODO` must have an owner or issue reference: `TODO(#123): ...`.

## Complexity smells → fixes
| Smell | Fix |
|---|---|
| Nesting > 3 levels | Guard clauses, extract function |
| Long parameter list | Parameter object, builder |
| Switch on type repeated in many places | Polymorphism / strategy map |
| Feature envy (method uses another object's data) | Move method |
| Primitive obsession | Value object / enum |
| Shotgun surgery (one change → many files) | Consolidate responsibility |
| God class / utils dumping ground | Split by responsibility |
| Temporal coupling (must call A before B) | Make it impossible: constructor/builder enforces order |

## Language-specific baseline (apply if relevant)
- **Python:** PEP 8, type hints, `ruff` + `mypy`/`pyright`, dataclasses/pydantic, f-strings, `pathlib`, no mutable default args.
- **JS/TS:** `strict: true`, ESLint + Prettier, `const` by default, `async/await` (no floating promises), no `any` without justification, `===`.
- **Java/Kotlin:** immutability, `Optional` for return values, records/data classes, no checked-exception swallowing.
- **Go:** `gofmt`, `go vet`, errors wrapped with `%w`, small interfaces defined by consumers, `context.Context` first param.
- **C#:** nullable reference types on, `async` all the way, `IDisposable` with `using`.
- **PHP:** `declare(strict_types=1)`, PSR-12, typed properties.
- **SQL:** uppercase keywords, explicit column lists (no `SELECT *` in app code), meaningful aliases.

## Output
When improving code: show the improved version, then a short list of the key changes and why. Don't change behavior unless asked — if a bug is found, call it out separately.
