---
name: sec-threat-modeling
description: Run a lightweight, practical threat model for a feature, system or architecture change - data-flow diagram, trust boundaries, STRIDE threats, abuse cases, risk rating and mitigations mapped to tests. Use at design time for new features, new integrations, auth or payment flows, file handling, multi-tenant or AI features, or when asked "what could go wrong?".
---

# Threat Modeling (lightweight)

Answer four questions: **What are we building? What can go wrong? What are we doing about it? Did we do a good job?**

## Steps
1. **Describe the system** in 5–10 lines: purpose, users/roles, data handled (with classification), external systems.
2. **Draw a data-flow diagram** with trust boundaries (browser ↔ API, API ↔ DB, API ↔ third party, tenant ↔ tenant, user ↔ admin, LLM ↔ tools):
   ```mermaid
   flowchart LR
     subgraph Internet
       U[User browser]
     end
     subgraph App[Trust boundary: our cloud]
       API[API] --> DB[(DB)]
       API --> Q[[Queue]] --> W[Worker]
     end
     U -->|HTTPS + session cookie| API
     W -->|HTTPS| P[Payment provider]
   ```
3. **Enumerate threats** per element/flow with STRIDE:
   | STRIDE | Question | Typical mitigations |
   |---|---|---|
   | **S**poofing | Can someone pretend to be another user/service? | Strong authN, MFA, mTLS, signed webhooks |
   | **T**ampering | Can data/requests be modified? | Server-side validation, integrity checks, signatures, DB constraints |
   | **R**epudiation | Can someone deny an action? | Audit logs with actor/target/trace |
   | **I**nformation disclosure | Can data leak to the wrong party? | AuthZ + tenant scoping, encryption, minimal responses, safe errors |
   | **D**enial of service | Can it be exhausted or blocked? | Rate limits, quotas, timeouts, size limits, autoscaling |
   | **E**levation of privilege | Can someone gain rights they shouldn't? | Deny-by-default, least privilege, no mass assignment, sandboxing |
4. **Add abuse cases** from the business view: "attacker reuses a coupon 1000×", "user exports all customers", "competitor scrapes prices", "insider deletes audit logs", "prompt injection makes the agent send emails".
5. **Rate risk** = likelihood × impact (Low/Med/High) considering exposure, attacker effort, data sensitivity.
6. **Decide per threat**: mitigate / eliminate (remove the feature or data) / transfer / accept (with owner + expiry).
7. **Turn mitigations into work**: tickets, security requirements, and **tests** (negative tests, abuse tests) — a mitigation without a test is a hope.
8. **Revisit** when the design changes or after incidents.

## Output template
```markdown
## Threat model: <feature>  (date, author, reviewers)
### Overview & assets
### Data-flow diagram (with trust boundaries)
### Threats
| # | Element/flow | STRIDE | Threat / abuse case | Likelihood | Impact | Risk | Mitigation | Test / evidence | Status |
### Assumptions & out of scope
### Accepted risks (owner, expiry, compensating controls)
```

## Rules
- Proportional: 15–30 minutes for a normal feature; deeper for auth, payments, multi-tenant, file processing, AI agents, or regulated data.
- Prefer eliminating risky data/capabilities over mitigating them.
- Be concrete — "attacker changes `invoiceId` in URL to read another tenant's invoice", not "data breach".
