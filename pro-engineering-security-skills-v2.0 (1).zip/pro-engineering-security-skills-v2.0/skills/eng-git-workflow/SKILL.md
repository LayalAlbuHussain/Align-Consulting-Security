---
name: eng-git-workflow
description: Professional Git and collaboration workflow - branching strategy, atomic commits, Conventional Commits messages, pull request descriptions, code-owner reviews, semantic versioning, changelogs and releases, and recovering from Git mistakes. Use when committing, writing a commit or PR message, planning branches/releases, or fixing repository history.
---

# Git & Collaboration Workflow

## Branching
- **Trunk-based** (recommended): short-lived feature branches (< 2–3 days) off `main`, merged via PR; incomplete work hidden behind feature flags. `main` is always releasable.
- GitFlow only when you truly ship multiple maintained versions.
- Branch names: `feat/invoice-export`, `fix/login-timeout-123`, `chore/bump-deps`.
- Protect `main`: required PR reviews (incl. CODEOWNERS for sensitive paths), required status checks (build, tests, lint, security scans), no force-push, linear history if preferred.

## Commits
- **Atomic**: one logical change per commit; the build passes at every commit.
- **Conventional Commits**:
  ```
  <type>(<scope>): <imperative summary, ≤ 72 chars>

  <why the change was needed and what it does — wrap at 72>

  Refs: #123
  BREAKING CHANGE: <description, if any>
  ```
  Types: `feat`, `fix`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`, `revert`, `security`.
- Message explains **why**; the diff shows what. Imperative mood: "Add", not "Added".
- Never commit: secrets, `.env`, credentials, large binaries, build output, IDE files, personal config. Maintain `.gitignore`; use pre-commit hooks (formatter, linter, secret scanner like gitleaks).
- If a secret is committed: **rotate it immediately** (history rewriting is not enough — assume it leaked), then purge history if required.

## Pull requests
- Small (ideally < 400 changed lines), focused, self-reviewed before requesting review.
- Description template:
  ```markdown
  ## What & why
  ## How (approach, key decisions)
  ## Screenshots / API examples (if UI/API)
  ## Testing (what was run, results)
  ## Risk & rollback (migrations, flags, config)
  ## Security considerations (auth, data, inputs) — or "none"
  Closes #123
  ```
- Respond to every review comment; resolve with a change or a reasoned reply.
- Prefer squash-merge for feature branches (clean history) unless the team values per-commit history.

## Versioning & releases
- **SemVer** `MAJOR.MINOR.PATCH`: breaking → MAJOR, feature → MINOR, fix → PATCH.
- Generate changelogs from Conventional Commits (release-please, semantic-release, changesets). Keep a human-readable `CHANGELOG.md` ("Keep a Changelog" format).
- Tag releases (`v1.4.0`), sign tags/commits where the org requires it.

## Recovering safely
| Situation | Command |
|---|---|
| Undo last local commit, keep changes | `git reset --soft HEAD~1` |
| Undo a pushed commit (shared branch) | `git revert <sha>` (never rewrite shared history) |
| Fix last commit message (not pushed) | `git commit --amend` |
| Find the commit that introduced a bug | `git bisect start/bad/good` |
| Recover "lost" commits | `git reflog` |
| Update branch with main | `git fetch && git rebase origin/main` (own branch) or merge |
Use `--force-with-lease`, never plain `--force`, and only on your own branches.

## Output
Ready-to-paste commit message(s) and/or PR description, plus exact Git commands when relevant.
