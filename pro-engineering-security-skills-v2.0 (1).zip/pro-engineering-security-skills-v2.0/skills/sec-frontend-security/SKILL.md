---
name: sec-frontend-security
description: Secure browser and mobile front ends - XSS prevention, safe rendering, Content Security Policy and security headers, clickjacking, token and browser storage, CSRF from the client side, third-party scripts, open redirects, postMessage, and secrets in bundles. Use when building or reviewing UI code, dashboards, rendering user content, or configuring headers.
---

# Frontend Security
Policy controls: SEC-004, SEC-008.

## XSS prevention
- Rely on the framework's auto-escaping (React, Vue, Angular, Svelte templates). **Dangerous sinks** need justification and sanitization:
  `dangerouslySetInnerHTML`, `v-html`, `[innerHTML]` / `bypassSecurityTrust*`, `{@html}`, `innerHTML`/`outerHTML`/`insertAdjacentHTML`, `document.write`, `eval`/`new Function`/`setTimeout(string)`, jQuery `.html()`.
- If HTML from users is required (rich text, Markdown): sanitize with **DOMPurify** (or a vetted server-side sanitizer) using an allowlist config; render Markdown with raw HTML disabled.
- URLs from users: allow only `https:` (and `mailto:` if needed) — block `javascript:`, `data:`, `vbscript:` in `href`/`src`.
- Never build HTML/JS/CSS by string concatenation with untrusted data. Encode for the correct context (HTML body, attribute, URL, JS, CSS).
- Enable **Trusted Types** where supported to lock down DOM sinks.

## Security headers (set on the server/CDN)
```
Content-Security-Policy: default-src 'self'; script-src 'nonce-{random}' 'strict-dynamic'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; upgrade-insecure-requests
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Cross-Origin-Opener-Policy: same-origin
```
- Start CSP in `Report-Only`, collect reports, fix violations, then enforce. Avoid `'unsafe-inline'` and `'unsafe-eval'` for scripts; use nonces/hashes.
- `frame-ancestors 'none'` (or a specific allowlist) prevents clickjacking; add `X-Frame-Options: DENY` for legacy browsers.

## Tokens and browser storage
- Session/refresh tokens: `HttpOnly` `Secure` `SameSite` cookies (or BFF pattern). **Not** in `localStorage`/`sessionStorage`/IndexedDB by default — any XSS can steal them.
- Don't store PII or secrets in storage, URLs, or analytics events. Clear sensitive state on logout.
- Mobile: use Keychain/Keystore (secure storage), certificate pinning only with a rotation plan, no secrets in the app binary.

## Secrets in bundles
- Anything shipped to the browser/mobile app is **public**. Only publishable keys (e.g. map keys restricted by domain, Stripe publishable key) may be in client code.
- Check env prefixes (`NEXT_PUBLIC_`, `VITE_`, `REACT_APP_`) — never expose server secrets through them. Disable public source maps in production or upload them privately to error tracking.

## Other client-side risks
- **Open redirects**: validate `returnUrl`/`next` against an allowlist of relative paths.
- **postMessage**: always check `event.origin` against an allowlist and validate message shape; target specific origins when sending (never `*` with sensitive data).
- **Third-party scripts**: minimize; load with **Subresource Integrity** (`integrity` + `crossorigin`) when from a CDN; consider sandboxed iframes for widgets; review tag managers (they bypass code review).
- **`target="_blank"`**: modern browsers imply `noopener`, but add `rel="noopener noreferrer"` for user-supplied links.
- **Client-side authorization** is only UX. Every check must be repeated on the server.
- **Error pages/toasts**: no stack traces, internal IDs or tokens.
- **File downloads/previews**: serve user files from a separate domain or with `Content-Disposition: attachment` and correct `Content-Type`.
- **Dependencies**: keep frontend packages patched; audit in CI (`sec-supply-chain`).

## Required tests
- XSS payloads (`<img src=x onerror=alert(1)>`, `"><svg onload=...>`, `javascript:alert(1)` links) in every user-controlled field render inert.
- Response headers present on HTML responses (automated header test or scanner such as ZAP baseline).
- No secrets in the built bundle (grep build output for key patterns in CI).
- Open redirect parameter rejects absolute external URLs.
- App not framable by another origin.

## Non-negotiables
No secrets in client code, no unsanitized HTML sinks, no reliance on browser-only permission checks, and no claim of XSS safety without tests or a reviewed CSP.
