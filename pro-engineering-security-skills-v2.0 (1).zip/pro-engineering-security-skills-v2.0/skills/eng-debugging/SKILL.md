---
name: eng-debugging
description: Systematically diagnose and fix bugs, crashes, wrong output, exceptions, flaky tests, memory leaks and production incidents, finding the root cause instead of patching symptoms. Use when the user shares an error message, stack trace, unexpected behavior, "it doesn't work", or an incident.
---

# Debugging

## Method (scientific, not random)
1. **Capture the facts**: exact error text, stack trace, inputs, environment (OS, runtime, versions), when it started, what changed (deploy, dependency, config, data).
2. **Reproduce** reliably — ideally as a failing automated test. If not reproducible, add instrumentation and gather more data.
3. **Read the error carefully**: the first exception in the chain and the first frame in *your* code are usually the most informative.
4. **Form hypotheses** ranked by likelihood × ease of checking. State them explicitly.
5. **Test one hypothesis at a time**: logging, debugger breakpoints, assertions, minimal reproduction. Change one variable per experiment.
6. **Narrow the search space**: binary search over code (comment out halves), data (smallest failing input), and history (`git bisect`).
7. **Fix the root cause**, not the symptom. Ask "why?" until you reach a cause you can prevent (5 Whys).
8. **Prove the fix**: the regression test fails before, passes after; run the related suite.
9. **Prevent recurrence**: validation, types, assertions, monitoring, docs.

## Common root-cause catalog
| Symptom | Usual suspects |
|---|---|
| `null`/`undefined`/`NoneType` errors | Missing data path, async not awaited, optional field, wrong key |
| Works locally, fails in prod | Env vars/config, versions, file paths/case sensitivity, permissions, timezone/locale, network/DNS, data volume |
| Intermittent failures | Race conditions, shared state, timeouts, retries, caching, ordering assumptions, clock |
| Wrong numbers | Float precision, integer division, rounding, units, timezone, off-by-one |
| Slowly gets worse | Memory/connection/file-handle leak, unbounded cache/queue, log growth |
| Encoding garbage (e.g. broken Arabic) | Mixed encodings, missing `utf8mb4`, wrong `Content-Type` charset, byte vs char slicing |
| CORS errors in browser | Server headers/preflight handling (fix server, not the browser) |
| "It worked yesterday" | `git log`, dependency lockfile diff, config change, expired cert/token, data change |

## Tools
- Debuggers (IDE, `pdb`/`debugpy`, Chrome DevTools, `dlv`, `gdb/lldb`), structured logs with correlation IDs, traces, profilers, `strace`/`tcpdump` for system-level issues, `git bisect` for regressions.
- Minimal reproduction: strip everything not needed to trigger the bug — often reveals the cause.

## Rules
- Don't "fix" by catching and ignoring the exception, adding sleeps, or bumping timeouts without understanding why.
- Don't change multiple things at once.
- Remove temporary debug logging before committing (or convert it to proper structured logs).
- If you can't run the code, give the user a precise diagnostic plan: what to log/check and what each result would mean.

## Production incidents
1. Mitigate first (rollback, feature flag off, scale up, block bad traffic) — restore service.
2. Communicate status and impact.
3. Then root-cause with logs/metrics/traces.
4. Blameless postmortem: timeline, impact, root cause, contributing factors, what went well, action items with owners.

## Output
Root cause (with evidence) → fix (code) → regression test → how to verify → prevention ideas. If uncertain, list ranked hypotheses with the check for each.
