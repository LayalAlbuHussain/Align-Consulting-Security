---
name: sec-api-security
description: Secure REST, GraphQL, gRPC and webhook APIs against the OWASP API Security Top 10 - object/property/function-level authorization, input schemas, rate and resource limits, CORS, safe errors, API keys, inventory and third-party API consumption. Use when creating, changing or reviewing any API endpoint or integration. Pair with eng-api-design.
---

# API Security
Policy controls: SEC-003, SEC-004, SEC-005.

## OWASP API Security Top 10 (2023) — controls
| Risk | Control |
|---|---|
| API1 Broken Object Level Authorization | Check ownership/tenant for every object ID in path, query **and** body (`sec-authorization`) |
| API2 Broken Authentication | Proven IdP, validated tokens, rate-limited auth endpoints (`sec-authentication`) |
| API3 Broken Object Property Level Authorization | Response DTOs with allowlisted fields per role (no excessive data exposure); input DTOs with allowlisted writable fields (no mass assignment) |
| API4 Unrestricted Resource Consumption | Rate limits, max page size, payload size limits, timeouts, query complexity limits, upload limits, cost budgets |
| API5 Broken Function Level Authorization | Role/permission check per operation; admin routes separated and deny-by-default |
| API6 Unrestricted Access to Sensitive Business Flows | Anti-automation on flows like signup, checkout, OTP, coupons (per-user limits, bot detection, step-up) |
| API7 Server-Side Request Forgery | URL allowlists and egress controls (`sec-backend-security`) |
| API8 Security Misconfiguration | Strict CORS, security headers, TLS only, no verbose errors, disabled debug/unused methods |
| API9 Improper Inventory Management | Every endpoint documented with owner and version; old versions retired; no shadow/test APIs exposed |
| API10 Unsafe Consumption of APIs | Validate third-party responses, timeouts, TLS verification, don't follow redirects blindly, treat as untrusted input |

## Endpoint checklist
- [ ] Authentication required (explicitly mark the rare public endpoints).
- [ ] Function-level permission + object-level + tenant check.
- [ ] Request validated by a **schema** (types, formats, lengths, ranges, enums, required fields, `additionalProperties: false`); reject unknown fields on writes.
- [ ] Response serialized through an explicit DTO; no internal fields (password hashes, tokens, internal IDs/flags, other users' PII).
- [ ] Pagination enforced with max `limit`; filters/sorts by allowlist.
- [ ] Request body size limit, request timeout, rate limit (per user/API key/IP) returning `429` + `Retry-After`.
- [ ] Errors use a safe generic format with `traceId` (no stack traces, SQL, paths, versions).
- [ ] Idempotency for retried writes; replay protection for webhooks.
- [ ] Audit log for sensitive operations (`sec-audit-logging`).
- [ ] Documented in OpenAPI/schema with auth + permission + owner.

## CORS
- Allowlist exact origins per environment; never reflect arbitrary `Origin`; never `*` with credentials; restrict methods/headers; cache preflight sensibly. CORS is not authentication.

## API keys & service tokens
- Treat as secrets: high entropy, shown once, stored **hashed**, prefixed for secret-scanning (e.g. `sk_live_`), scoped (least privilege), expiring, rotatable, revocable, tied to an owner, logged by key ID (never value).
- Keys go in the `Authorization` header, never in URLs.

## GraphQL
Depth and complexity limits, max aliases/batch size, persisted queries for public clients, field-level authorization in resolvers, introspection disabled in production for private APIs, DataLoader with per-request scope (no cross-user cache leaks), error masking.

## Webhooks (inbound)
Verify HMAC signature over raw body with constant-time compare; reject old timestamps (e.g. > 5 min); dedupe by event ID; process async; fetch authoritative state from the provider API for critical actions.

## Required negative tests
401 without/expired token · 403/404 cross-user and cross-tenant (read, update, delete, list, export) · 403 for lower role on admin functions · 400 for wrong types/unknown fields/oversize strings · 413 oversize body · 429 after limit · sensitive fields absent from responses · mass-assignment attempt (`role`, `tenantId`) has no effect · CORS rejects unlisted origin · webhook with bad signature/old timestamp rejected.

## Non-negotiables
Never trust client-supplied identity/tenant/role; never expose secrets/PII in responses or logs; never mark an endpoint secure without tests or evidence — state what was not verified.
