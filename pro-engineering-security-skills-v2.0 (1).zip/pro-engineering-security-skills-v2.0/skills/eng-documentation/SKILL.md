---
name: eng-documentation
description: Write clear technical documentation - READMEs, setup guides, API references, architecture overviews, ADRs, runbooks, code comments/docstrings and changelogs. Use when documenting a project, module, API or decision, onboarding developers, or when asked to explain or document code.
---

# Technical Documentation

## Principles
- Write for a specific reader (new dev, API consumer, on-call engineer) and their task.
- Docs live next to code, are versioned, and are updated in the same PR as the behavior change.
- Examples beat prose: every concept gets a runnable example. Commands must be copy-pasteable and tested.
- Be concise: short sentences, active voice, headings that scan, tables for options.
- Never include real secrets, internal hostnames, or customer data in docs or examples — use placeholders like `<YOUR_API_KEY>`.

## README template
```markdown
# Project name
One-paragraph purpose: what it does, for whom, why.

## Quick start
Prerequisites (with versions) → install → configure (.env.example) → run → open URL.

## Usage
Most common tasks with examples.

## Configuration
| Variable | Required | Default | Description |

## Development
Run tests, lint, format; project structure overview; conventions.

## Deployment
How it is built and released; environments.

## Troubleshooting
Known issues and fixes.

## Contributing · License · Contacts/owners
```

## Documentation types (Diátaxis)
| Type | Purpose | Example |
|---|---|---|
| Tutorial | Learning by doing | "Build your first integration" |
| How-to guide | Solve a specific task | "Rotate the signing key" |
| Reference | Exact facts | API endpoints, config options, CLI flags |
| Explanation | Understanding/why | Architecture overview, ADRs |
Don't mix them in one page.

## Code comments & docstrings
- Public functions/classes: purpose, parameters, return value, errors raised, side effects, example. Follow the language convention (JSDoc/TSDoc, Python docstrings (Google/NumPy style), Javadoc, GoDoc, XML docs).
- Inline comments explain *why* (constraints, business rules, workarounds with issue links), not *what*.
- Keep comments true — outdated comments are worse than none.

## Architecture docs
- Context diagram (system + external actors), container/component diagram (C4 model), key data flows, trust boundaries, deployment view. Mermaid diagrams render on GitHub/GitLab:
  ```mermaid
  flowchart LR
    User -->|HTTPS| Web[Web App] -->|REST| API[(API)] --> DB[(PostgreSQL)]
  ```
- Decisions in ADRs (template in `eng-architecture`).

## Runbooks (for on-call)
Alert name → what it means → impact → diagnosis steps (exact queries/dashboards) → mitigation steps → escalation contacts → post-incident follow-up.

## Bilingual docs
If the audience is Arabic-speaking, provide Arabic docs for user-facing/onboarding material while keeping code identifiers, commands and API names in English; keep both versions in sync (same structure, linked to each other).

## Output
The requested document in Markdown, with runnable examples and placeholders for anything you could not verify (marked clearly as "to confirm").
