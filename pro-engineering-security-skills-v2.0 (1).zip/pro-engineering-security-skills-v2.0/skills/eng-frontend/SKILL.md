---
name: eng-frontend
description: Build professional web and mobile UIs - component architecture, state management, data fetching, forms, accessibility (WCAG 2.2 AA), responsive design, internationalization including Arabic/RTL, loading/error/empty states, and frontend testing - in React, Vue, Angular, Svelte, Flutter, React Native or plain HTML/CSS/JS. Use when creating or changing UI code. Pair with sec-frontend-security.
---

# Frontend Engineering

## Components
- Small, focused components with clear props; separate **presentational** (render) from **container/data** logic (hooks/composables/services).
- Typed props (TypeScript / PropTypes / Dart types). No business rules buried in JSX/templates.
- Reuse the project's design system/component library before creating new primitives.
- Co-locate component, styles, tests and stories.

## State
- Pick the minimal home for each piece of state: local → lifted → context/store → URL (filters, tabs, pagination belong in the URL) → server cache.
- Server data via a cache library (TanStack Query, SWR, RTK Query, Apollo, Angular services with signals) — handles caching, dedupe, retries, invalidation. Don't copy server data into global stores by hand.
- Derive, don't duplicate: compute values from state instead of storing them twice.

## Every async view has 4 states
**Loading** (skeleton/spinner) · **Error** (human message + retry, no stack traces) · **Empty** (helpful call to action) · **Success**. Also handle slow networks, double-clicks (disable while submitting), and optimistic updates with rollback.

## Forms
- Schema validation (Zod, Yup, Valibot, class-validator…) shared with the backend where possible; **server validation is still mandatory**.
- Label every field; show errors next to fields and in a summary; preserve user input on error; correct `type`/`inputmode`/`autocomplete` attributes.

## Accessibility (WCAG 2.2 AA — required, not optional)
- Semantic HTML first (`button`, `nav`, `main`, `label`, `table`); ARIA only to fill gaps.
- Full keyboard support: logical tab order, visible focus, no keyboard traps, `Esc` closes dialogs, focus moves into and back from modals.
- Text contrast ≥ 4.5:1 (3:1 large text/UI components); don't convey info by color alone.
- Images have meaningful `alt` (empty `alt=""` for decorative). Icon-only buttons have accessible names.
- Target size ≥ 24×24 CSS px; respect `prefers-reduced-motion`.
- Announce dynamic changes (`aria-live`) for toasts/validation.
- Test with axe/Lighthouse + keyboard-only + a screen reader pass for key flows.

## Internationalization & RTL (Arabic)
- No hard-coded user-facing strings — use i18n keys (i18next, FormatJS, vue-i18n, Angular i18n, Flutter intl).
- Set `<html lang="ar" dir="rtl">` per locale; use **CSS logical properties** (`margin-inline-start`, `padding-inline-end`, `inset-inline-start`, `text-align: start`) instead of left/right.
- Mirror directional icons (arrows, back/next) in RTL; don't mirror logos, media controls or numbers.
- Format numbers, dates, currency with `Intl` APIs and the locale (e.g. `ar-SA`, `SAR`); decide on Arabic-Indic vs Latin digits consistently; support Hijri calendar if the product needs it.
- Handle bidirectional text (mixed Arabic + English/numbers) with `dir="auto"` or `<bdi>` for user-generated content.
- Use fonts with proper Arabic shaping; never truncate by bytes; test long translations.

## Responsive & styling
- Mobile-first, fluid layouts (flex/grid), relative units; test common breakpoints and zoom 200%.
- Consistent design tokens (colors, spacing, typography); dark mode via tokens if supported.
- Avoid layout shift: reserve space for images/ads/async content.

## Performance
Code-split routes, lazy-load heavy components, optimize images, virtualize long lists, memoize only where profiling shows benefit. Targets: LCP < 2.5 s, INP < 200 ms, CLS < 0.1 (see `eng-performance`).

## Security reminders (details in `sec-frontend-security`)
No secrets or privileged API keys in the bundle; no raw HTML injection of untrusted data; tokens not in `localStorage` by default; UI permission checks are UX only — the server enforces.

## Testing
- Unit/component tests with Testing Library (query by role/label like a user), Vitest/Jest, Flutter widget tests.
- E2E for critical journeys (Playwright/Cypress) including an RTL locale run.
- Automated a11y checks (axe) in CI; visual regression for design-system components if available.

## Output
Component code with types, states (loading/error/empty), a11y attributes, i18n keys (with `ar` and `en` examples when relevant), and tests.
