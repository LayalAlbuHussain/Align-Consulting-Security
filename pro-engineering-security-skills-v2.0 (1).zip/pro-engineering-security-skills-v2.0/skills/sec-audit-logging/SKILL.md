---
name: sec-audit-logging
description: Design security audit logging and detection - which security events to record, event schema, privacy-safe redaction, tamper resistance, retention, access control, and alerting on suspicious activity. Use when implementing login, permission changes, admin or privileged actions, sensitive data access or exports, or incident investigation capability.
---

# Security Audit Logging & Detection
Policy controls: SEC-006, SEC-010. (General application logging: `eng-observability`.)

## Events that MUST be audited
- Authentication: login success/failure, MFA challenge result, logout, lockout, password/MFA change, password reset request/complete, session revocation.
- Authorization: access denied (403/404 on protected objects), permission/role changes, tenant membership changes, API key create/rotate/revoke.
- Privileged/admin actions: user impersonation, configuration changes, feature-flag changes in production, data deletion, bulk operations.
- Sensitive data: viewing Restricted data, exports/downloads/reports (with row counts), sharing links created.
- Security signals: validation failures in bulk, rate-limit triggers, webhook signature failures, CSRF failures, suspicious input patterns.

## Event schema
```json
{
  "timestamp": "2026-01-31T09:30:00.123Z",
  "eventType": "auth.login.failed",
  "outcome": "failure",
  "actor": { "userId": "u_8f2", "tenantId": "t_12", "type": "user", "ip": "203.0.113.7", "userAgent": "..." },
  "action": "login",
  "target": { "type": "account", "id": "u_8f2" },
  "reason": "invalid_credentials",
  "traceId": "4bf92f3577b34da6",
  "service": "auth-api", "env": "prod", "version": "1.8.2"
}
```
Answer: **who** did **what** to **which target**, **when**, from **where**, with what **result**, and how to correlate (`traceId`).

## Privacy & safety
- **Never log**: passwords, OTPs, tokens, session IDs, API keys, private keys, full card numbers, full national IDs, raw request bodies with PII.
- Use stable pseudonymous IDs; mask or hash identifiers where the raw value isn't needed; strip CR/LF from user values (log injection).
- Centralized redaction in the logger, plus a test that captures logs and asserts no secrets/PII.

## Integrity, retention & access
- Ship to a central log platform (SIEM) quickly; app servers shouldn't be the only copy.
- Append-only/WORM storage or hash-chaining for high-assurance audit trails; synchronized clocks (NTP).
- Restrict who can read audit logs (they contain sensitive metadata); log access to logs.
- Retention per policy/regulation (e.g. 1 year hot+cold is common — confirm with compliance).
- Audit logging must be **reliable**: failures to write critical audit events are themselves alerted; consider outbox/queue to avoid loss.

## Detection & alerting (examples)
- N failed logins for one account or from one IP within M minutes (brute force / credential stuffing).
- Login from new country/device for privileged users; impossible travel.
- Spike in 403/404 on object endpoints from one user (IDOR probing).
- Large or unusual exports; off-hours admin actions; role escalations; MFA disabled.
- Every alert has an owner and a runbook.

## Required tests
- Each mandatory event type is emitted with required fields for both success and failure paths.
- Denied requests emit an access-denied event without the sensitive payload.
- Log-capture test proves tokens/passwords/PII are absent.
- Audit write failure triggers an error metric/alert.

## Non-negotiables
No secrets or sensitive payloads in logs; audit trails are not optional for privileged actions; report gaps honestly.
