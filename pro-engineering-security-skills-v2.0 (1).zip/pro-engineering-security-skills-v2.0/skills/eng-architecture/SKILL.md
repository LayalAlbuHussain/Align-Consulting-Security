---
name: eng-architecture
description: Design software structure and systems - module boundaries, layering, design patterns, monolith vs services, data flow, scalability, consistency, and Architecture Decision Records (ADRs). Use when starting a project, adding a significant feature, choosing a stack or pattern, splitting a system, or when asked "how should I structure this?".
---

# Software Architecture & Design

## Workflow
1. **Clarify drivers** — functional scope, quality attributes (latency, throughput, availability, security, cost, team size, time-to-market), constraints (existing stack, compliance, budget). Quantify where possible ("p95 < 300 ms at 200 rps").
2. **Map the domain** — core entities, their invariants, who owns which data, main use cases. Name things with the business's language (ubiquitous language).
3. **Propose 2–3 options** with trade-offs; recommend one. Simplest viable option first.
4. **Draw the boundaries** — components, responsibilities, data ownership, sync vs async interactions, trust boundaries (feed into `sec-threat-modeling`).
5. **Record the decision** as an ADR (template below).
6. **Plan evolution** — what must be easy to change later, and what you are deliberately not building now.

## Default recommendations
- **Start with a modular monolith.** Clear internal modules with explicit interfaces; extract services only when there is a proven need (independent scaling, deploy cadence, team ownership, fault isolation). Microservices cost: network failures, distributed transactions, observability, ops.
- **Layering (ports & adapters / clean architecture):**
  - *Domain*: entities, value objects, business rules — no framework/DB imports.
  - *Application*: use cases/services orchestrating domain + ports (interfaces).
  - *Infrastructure/adapters*: DB repositories, HTTP clients, queues, framework controllers.
  - Dependencies point inward. Controllers stay thin: parse → call use case → map response.
- **Organize by feature/module** (`billing/`, `orders/`) rather than by technical type (`controllers/`, `models/`) once the app is non-trivial.
- **One owner per piece of data.** Other modules access it through the owner's API, not its tables.
- **Stateless app tier;** state in DB/cache/object storage so instances can scale horizontally.
- **Configuration via environment** (12-factor); same artifact promoted across environments.

## Pattern guide (use only when the problem exists)
| Problem | Pattern |
|---|---|
| Swap algorithms/behaviors at runtime | Strategy |
| Complex object creation | Factory / Builder |
| Integrate an incompatible external API | Adapter / Anti-corruption layer |
| Notify many parts on an event | Observer / domain events / pub-sub |
| Decouple data access from domain | Repository |
| Cross-cutting concerns (auth, logging, retries) | Middleware / Decorator |
| Long multi-step business process across services | Saga (orchestration or choreography) |
| Reliable "write DB + publish event" | Transactional outbox |
| Read/write models diverge heavily | CQRS (only if really needed) |
| Unreliable downstream | Timeout + retry with backoff + jitter + circuit breaker + bulkhead |

## Distributed-system rules
- Every network call can fail, be slow, or succeed twice. Use timeouts everywhere, idempotency keys for writes, and at-least-once consumers that are idempotent.
- Prefer async messaging for work that need not block the user; return `202 Accepted` + status resource.
- Know your consistency model; document where eventual consistency is acceptable and how the UI handles it.
- Cache with explicit TTL and invalidation strategy; never cache authorization decisions across tenants.
- Design for observability from day one (see `eng-observability`).

## Scalability checklist
- Bottleneck identified by measurement, not guesswork (see `eng-performance`).
- DB: indexes, connection pooling, read replicas, partitioning only when needed.
- Background jobs for heavy work; queues with dead-letter handling.
- Rate limits and backpressure at the edges.
- CDN for static assets; pagination for all list endpoints.

## ADR template
```markdown
# ADR-NNN: <decision title>
Date: YYYY-MM-DD · Status: proposed | accepted | superseded by ADR-XXX
## Context
<forces, constraints, quality attributes, what triggered the decision>
## Options considered
1. <option> — pros / cons
2. <option> — pros / cons
## Decision
<chosen option and why>
## Consequences
<positive, negative, risks, follow-up work, what would make us revisit>
```

## Output
For design questions deliver: summary recommendation → component diagram (Mermaid or ASCII) → responsibilities table → key flows → trade-offs/risks → ADR draft. Keep it proportional to the question.
