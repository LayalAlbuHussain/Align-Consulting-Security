---
name: eng-refactoring
description: Safely restructure existing or legacy code without changing behavior - characterization tests, small reversible steps, extracting functions/modules, removing duplication and dead code, strangler-fig migrations, upgrading frameworks. Use when asked to refactor, clean up, modernize, migrate, or reduce technical debt.
---

# Refactoring & Legacy Code

Refactoring = changing structure **without** changing behavior. Feature work and refactors go in separate commits (ideally separate PRs).

## Safety net first
1. Identify the behavior to preserve. If tests are missing, write **characterization tests** that pin current behavior (including odd behavior — note suspected bugs separately, don't fix silently).
2. Ensure tests run fast and green before touching anything.
3. Commit after every small green step so any step can be reverted.

## Process
1. State the goal: what pain does this fix (readability, testability, performance, coupling)? Define "done".
2. Make the change easy, then make the easy change (Kent Beck).
3. Use automated IDE refactorings where possible (rename, extract, inline, move) — they are safer than manual edits.
4. One refactoring at a time; run tests after each.
5. Keep public APIs stable; if they must change, deprecate first, provide an adapter, migrate callers, then remove.

## Catalog (smell → refactoring)
| Smell | Refactoring |
|---|---|
| Long function | Extract function; replace temp with query; decompose conditional |
| Duplicate code | Extract function/module; pull up method; template method |
| Large class | Extract class; split by responsibility |
| Long parameter list | Introduce parameter object; preserve whole object |
| Complex conditionals | Guard clauses; replace conditional with polymorphism/lookup table |
| Global state / singletons | Dependency injection; pass explicit context |
| Hard-wired dependencies (DB, HTTP, time) | Introduce interface/port + adapter (seam) |
| Primitive obsession | Introduce value object/enum |
| Dead code / unused flags | Delete (Git has history) |
| Mutable shared data | Encapsulate; make immutable; copy on write |

## Legacy code techniques
- **Seams**: find a place to alter behavior without editing (dependency injection, subclass-and-override, wrapper) to get code under test.
- **Sprout method/class**: add new behavior in new, tested code called from the legacy code.
- **Strangler fig**: route traffic gradually from the old system to the new one (proxy/facade/feature flag), module by module, until the old one can be removed.
- **Branch by abstraction**: introduce an abstraction, implement the new version behind it, switch over, delete the old.
- **Parallel run / shadow traffic**: compare old vs. new outputs before switching critical logic.

## Framework / dependency upgrades
Read release notes and migration guides; upgrade one major version at a time; fix deprecation warnings first; use official codemods; run the full test suite and smoke tests; deploy behind a canary.

## Rules
- No behavior changes hidden in a refactor PR. If you find a bug, report it and fix it in a separate change with a regression test.
- Don't refactor code you don't need to touch for the current goal unless it's agreed scope.
- Measure before claiming performance improvements.

## Output
Step-by-step refactoring plan → code per step (or final code with the sequence explained) → tests proving behavior is unchanged → follow-ups.
