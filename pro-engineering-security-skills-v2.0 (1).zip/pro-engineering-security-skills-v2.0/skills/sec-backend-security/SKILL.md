---
name: sec-backend-security
description: Secure server-side code - injection (SQL, NoSQL, OS command, LDAP, template), SSRF, file uploads and path traversal, XML/XXE, unsafe deserialization, ReDoS, race conditions, cryptography usage, outbound HTTP clients, queues and background jobs, and least-privilege service identities. Use when writing or reviewing backend, worker, integration or server-rendered code.
---

# Backend Security
Policy controls: SEC-004, SEC-009.

## Input handling
- Validate every untrusted input (HTTP, queue messages, files, webhooks, env from users, DB data originally from users) with a **schema**: type, length, format, range, enum, allowlist. Reject, don't "clean".
- Normalize before validating (Unicode NFC, case where appropriate, canonical paths).
- Output-encode for the destination context (HTML, SQL, shell, LDAP, logs).

## Injection
| Type | Do | Never |
|---|---|---|
| SQL | Parameterized queries/ORM bindings; allowlist identifiers (sort columns, table names) | String concat/f-strings/template literals with input |
| NoSQL | Validate types (reject objects where strings expected); use driver query builders | Pass raw JSON bodies as query filters (`{"$ne": null}`) |
| OS command | Avoid the shell; use library APIs; if needed, exec with **argument arrays** (`subprocess.run([...], shell=False)`), allowlisted values, `--` before user args | `shell=True`, `exec(string)`, backticks with input |
| Template (SSTI) | Static templates; pass data as variables; sandboxed engines | Rendering user-provided template strings |
| LDAP/XPath | Library escaping functions, parameterized filters | Concatenation |
| Log injection | Structured logging; strip CR/LF from user values | Writing raw user input into log lines |
| Header injection | Framework header APIs (reject CR/LF) | Building raw headers |

## SSRF (any server-side fetch of a user-influenced URL)
- Prefer an **allowlist** of destinations (scheme + host + port). If arbitrary URLs are a feature (webhooks, URL previews, imports):
  - Allow only `https` (and `http` if required); resolve DNS, **block private/reserved ranges** (10/8, 172.16/12, 192.168/16, 127/8, 169.254/16 incl. cloud metadata `169.254.169.254`, `::1`, `fc00::/7`, `fe80::/10`, `0.0.0.0`) and **connect to the validated IP** (prevents DNS rebinding).
  - Disable or re-validate redirects; set short timeouts and max response size; strip credentials.
  - Run fetchers in an isolated network segment/egress proxy; enforce IMDSv2 / metadata protection on cloud hosts.

## Files
- **Uploads:** enforce size limits; verify type by magic bytes + extension allowlist; generate random storage names; store outside the web root (object storage, private bucket); serve via signed URLs or with `Content-Disposition: attachment` + correct `Content-Type` + `X-Content-Type-Options: nosniff`; malware-scan where relevant; re-encode images (strips metadata/polyglots); limit archive extraction (zip bombs, zip-slip path checks).
- **Path traversal:** never join user input into paths directly. Map IDs to paths, or canonicalize (`realpath`) and verify the result stays within the base directory.

## Parsers & deserialization
- XML: disable DTDs/external entities (XXE) in the parser config.
- Never deserialize untrusted data with native formats that execute code (Python `pickle`, Java native serialization, .NET `BinaryFormatter`, PHP `unserialize`, Ruby `Marshal`, `yaml.load` → use `yaml.safe_load`). Use JSON + schema validation.
- Regular expressions on user input: avoid catastrophic backtracking (nested quantifiers); use timeouts or linear-time engines (RE2); limit input length.
- JavaScript: guard against **prototype pollution** (reject `__proto__`, `constructor`, `prototype` keys; use `Object.create(null)`/`Map`; safe merge libs).

## Concurrency & business logic
- Race conditions on balance, inventory, coupon, voting, signup: use DB constraints, transactions with proper locking, or atomic operations; idempotency keys for retried requests.
- Validate business invariants server-side (price, quantity ≥ 1, discount limits) — never trust client-calculated totals.
- TOCTOU: check and act atomically.

## Cryptography
- Use vetted high-level libraries (libsodium/NaCl, Tink, platform crypto). Never invent algorithms or modes.
- Symmetric: AES-256-GCM or ChaCha20-Poly1305 with unique nonces; hashing: SHA-256+; passwords: Argon2id/bcrypt/scrypt (see `sec-authentication`); MAC: HMAC-SHA-256; signatures: Ed25519 or ECDSA P-256.
- Randomness for security: CSPRNG only (`secrets`, `crypto.randomBytes`/`crypto.getRandomValues`, `SecureRandom`, `crypto/rand`) — never `Math.random`/`random`.
- Constant-time comparison for tokens/MACs. TLS verification **always on** for outbound calls (no `verify=False`, `rejectUnauthorized: false`, `InsecureSkipVerify`).

## Service hardening
- Least-privilege service identities (DB user, cloud IAM role, API scopes); separate credentials per service and environment.
- Timeouts, max body size, connection limits; graceful handling of dependency failures.
- Disable debug modes, default credentials, directory listings, unused endpoints/admin consoles in production.
- Background jobs re-check authorization for the user/tenant they act on; queue messages are untrusted input.
- Keep runtime, framework and dependencies patched (`sec-supply-chain`).

## Required tests
SQLi/NoSQLi payloads rejected or inert · command injection payloads (`; id`, `$(id)`) have no effect · SSRF to `http://169.254.169.254/`, `http://127.0.0.1:port`, DNS-rebinding hosts and redirect chains blocked · `../../etc/passwd` and absolute paths rejected · oversize/wrong-type uploads rejected · XXE payload not resolved · concurrent double-spend test keeps invariants.

## Non-negotiables
No string-built queries/commands, no disabled TLS verification, no untrusted deserialization, no secrets in code or logs; report residual risks and anything not tested.
