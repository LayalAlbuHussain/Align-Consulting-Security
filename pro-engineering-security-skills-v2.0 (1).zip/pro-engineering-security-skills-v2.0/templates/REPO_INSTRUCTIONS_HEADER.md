# AI assistant instructions for this repository

These instructions apply to every AI coding assistant working in this repository.
Baseline policies: `policy/ENGINEERING_STANDARDS.md` and `policy/SECURITY_POLICY.md` (security wins on conflict).
Full skill playbooks: {SKILLS_LOCATION}. Load the matching skill before non-trivial work.

## Project specifics (fill in during onboarding)
- Stack / versions: TBD
- Build: `TBD` · Test: `TBD` · Lint/format: `TBD` · Type check: `TBD`
- Application security tests: `TBD` (see `examples/ADAPTER_TEMPLATE.md`)
- Identity provider / tenant model: TBD
- Security owner: TBD

## Hard rules
- Do not bypass failing checks, weaken security gates, or use `continue-on-error` on them.
- Do not insert secrets; do not send internal code/secrets/customer data to unapproved services.
- Do not claim compliance or test success without real tool output.
- When rules conflict or information is missing: deny by default and ask the security owner.
