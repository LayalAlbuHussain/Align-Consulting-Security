## What & why
<!-- Problem solved, link to issue -->

## How
<!-- Approach and key decisions -->

## Testing
<!-- Commands run and real results; or "not run" + reason -->

## Risk & rollback
<!-- Migrations, feature flags, config changes, rollback plan -->

## Security considerations
<!-- AuthN/AuthZ, data, inputs, dependencies, AI usage — or "none" with reason -->

## Checklist
See `ci/PR_CHECKLIST.md` — confirm all applicable items.
