"""Build ready-to-install bundles of the skills pack for each AI platform.

Usage:  python tools/build_dist.py            # writes ./dist (deleted and rebuilt)

Outputs (see dist/README.md for install steps):
  skill-zips/            one .zip per skill  -> Claude.ai / Claude Desktop / ChatGPT "Skills" upload
  claude-code/           .claude/skills + CLAUDE.md + policy/
  codex-agents/          .agents/skills + AGENTS.md + policy/   (Codex, and any tool reading AGENTS.md)
  chat-projects/         INSTRUCTIONS.txt + knowledge/*.md      (Custom GPT, ChatGPT/Claude Projects, Gemini Gems)
  single-file/           ALL_SKILLS.md + SHORT_INSTRUCTIONS.txt (paste/attach anywhere)
  cursor/                .cursor/rules/*.mdc + AGENTS.md
  copilot/               .github/copilot-instructions.md + docs/ai-skills
  gemini-cli/            GEMINI.md + docs/ai-skills
Only uses the Python standard library.
"""
from __future__ import annotations

import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS_DIR = ROOT / "skills"
DIST = ROOT / "dist"
CORE = "eng-core-standards"
GPT_LIMIT, SHORT_LIMIT = 8000, 1500
FIXED_DATE = (2026, 1, 1, 0, 0, 0)


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def split_skill(path: Path) -> tuple[dict[str, str], str]:
    text = read(path)
    end = text.find("\n---", 4)
    meta = {}
    for line in text[4:end].splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
    return meta, text[end + 4:].strip() + "\n"


def load_skills() -> list[tuple[str, dict[str, str], str, Path]]:
    out = []
    for p in sorted(SKILLS_DIR.glob("*/SKILL.md")):
        meta, body = split_skill(p)
        out.append((p.parent.name, meta, body, p.parent))
    # core first, then eng-*, then sec-*
    out.sort(key=lambda s: (s[0] != CORE, not s[0].startswith("eng-"), s[0]))
    return out


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def skill_index(skills, location_fmt: str) -> str:
    rows = ["| Skill | Use when | File |", "|---|---|---|"]
    for name, meta, _, _ in skills:
        rows.append(f"| `{name}` | {meta['description']} | {location_fmt.format(name=name)} |")
    return "\n".join(rows) + "\n"


def repo_instructions(skills, skills_location: str, location_fmt: str) -> str:
    header = read(ROOT / "templates/REPO_INSTRUCTIONS_HEADER.md").replace("{SKILLS_LOCATION}", skills_location)
    core_body = next(b for n, _, b, _ in skills if n == CORE)
    return (header.rstrip() + "\n\n---\n\n" + core_body.rstrip()
            + "\n\n---\n\n## Skill index\n\n" + skill_index(skills, location_fmt))


def copy_skill_tree(skills, dest: Path) -> None:
    for name, _, _, folder in skills:
        shutil.copytree(folder, dest / name)


def copy_policy(dest: Path) -> None:
    shutil.copytree(ROOT / "policy", dest / "policy")


def flat_skill_docs(skills, dest: Path) -> None:
    for name, meta, body, _ in skills:
        write(dest / f"{name}.md", f"<!-- {meta['description']} -->\n{body}")


def bundle(skills, title: str) -> str:
    parts = [f"# {title}\n"]
    for name, meta, body, _ in skills:
        parts.append(f"\n\n========================================\n"
                     f"SKILL: {name}\nUSE WHEN: {meta['description']}\n"
                     f"========================================\n\n{body}")
    return "".join(parts)


def zip_dir(src: Path, zip_path: Path) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(src.rglob("*")):
            if f.is_file():
                info = zipfile.ZipInfo(str(Path(src.name) / f.relative_to(src)), FIXED_DATE)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                zf.writestr(info, f.read_bytes())


def main() -> int:
    skills = load_skills()
    if not skills or skills[0][0] != CORE:
        print("Core skill missing", file=sys.stderr)
        return 1
    gpt = read(ROOT / "templates/CUSTOM_GPT_INSTRUCTIONS.md").strip()
    short = read(ROOT / "templates/SHORT_INSTRUCTIONS.md").strip()
    if len(gpt) > GPT_LIMIT or len(short) > SHORT_LIMIT:
        print(f"Instruction templates too long: gpt={len(gpt)}/{GPT_LIMIT} short={len(short)}/{SHORT_LIMIT}", file=sys.stderr)
        return 1

    if DIST.exists():
        shutil.rmtree(DIST)
    eng = [s for s in skills if s[0].startswith("eng-") and s[0] != CORE]
    sec = [s for s in skills if s[0].startswith("sec-")]
    core = [s for s in skills if s[0] == CORE]

    # 1. Skill zips (Agent Skills format: folder/SKILL.md at zip root)
    for name, _, _, folder in skills:
        zip_dir(folder, DIST / "skill-zips" / f"{name}.zip")

    # 2. Claude Code
    d = DIST / "claude-code"
    copy_skill_tree(skills, d / ".claude/skills")
    write(d / "CLAUDE.md", repo_instructions(skills, "`.claude/skills/<name>/SKILL.md` (auto-discovered)",
                                             "`.claude/skills/{name}/SKILL.md`"))
    copy_policy(d)

    # 3. Codex + any AGENTS.md-aware tool
    d = DIST / "codex-agents"
    copy_skill_tree(skills, d / ".agents/skills")
    write(d / "AGENTS.md", repo_instructions(skills, "`.agents/skills/<name>/SKILL.md` (auto-discovered by Codex)",
                                             "`.agents/skills/{name}/SKILL.md`"))
    copy_policy(d)

    # 4. Chat projects / Custom GPT
    d = DIST / "chat-projects"
    write(d / "INSTRUCTIONS.txt", gpt + "\n")
    core_doc = bundle(core, "Core standards (always apply)") + "\n\n## Skill index\n\n" + \
        skill_index(skills, "{name} section in 02/03 knowledge files")
    write(d / "knowledge/01_CORE_AND_INDEX.md", core_doc)
    write(d / "knowledge/02_ENGINEERING_SKILLS.md", bundle(eng, "Engineering skills (eng-*)"))
    write(d / "knowledge/03_SECURITY_SKILLS.md", bundle(sec, "Security skills (sec-*)"))
    policies = "\n\n---\n\n".join(read(ROOT / p) for p in (
        "policy/ENGINEERING_STANDARDS.md", "policy/SECURITY_POLICY.md",
        "policy/QUALITY_GATES.md", "ci/PR_CHECKLIST.md", "examples/ADAPTER_TEMPLATE.md"))
    write(d / "knowledge/04_POLICIES.md", "# Policies, quality gates and checklists\n\n" + policies)

    # 5. Single file
    d = DIST / "single-file"
    write(d / "ALL_SKILLS.md", bundle(skills, "Professional Engineering & Security Skills — all playbooks")
          + "\n\n========================================\nPOLICIES\n========================================\n\n"
          + policies)
    write(d / "SHORT_INSTRUCTIONS.txt", short + "\n")

    # 6. Cursor
    d = DIST / "cursor"
    for name, meta, body, _ in skills:
        always = "true" if name == CORE else "false"
        desc = meta["description"].replace('"', "'")
        write(d / ".cursor/rules" / f"{name}.mdc",
              f'---\ndescription: "{desc}"\nglobs:\nalwaysApply: {always}\n---\n\n{body}')
    write(d / "AGENTS.md", repo_instructions(skills, "`.cursor/rules/*.mdc` (agent-requested by description)",
                                             "`.cursor/rules/{name}.mdc`"))
    copy_policy(d)

    # 7. GitHub Copilot
    d = DIST / "copilot"
    write(d / ".github/copilot-instructions.md", repo_instructions(
        skills, "`docs/ai-skills/<name>.md` (open the relevant file before non-trivial work)",
        "`docs/ai-skills/{name}.md`"))
    flat_skill_docs(skills, d / "docs/ai-skills")
    copy_policy(d)

    # 8. Gemini CLI
    d = DIST / "gemini-cli"
    write(d / "GEMINI.md", repo_instructions(
        skills, "`docs/ai-skills/<name>.md` (read the relevant file before non-trivial work)",
        "`docs/ai-skills/{name}.md`"))
    flat_skill_docs(skills, d / "docs/ai-skills")
    copy_policy(d)

    write(DIST / "README.md", read(ROOT / "templates/DIST_README.md"))
    count = sum(1 for _ in DIST.rglob("*") if _.is_file())
    print(f"Built dist/: {len(skills)} skills, {count} files "
          f"(GPT instructions {len(gpt)}/{GPT_LIMIT} chars, short {len(short)}/{SHORT_LIMIT} chars)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
