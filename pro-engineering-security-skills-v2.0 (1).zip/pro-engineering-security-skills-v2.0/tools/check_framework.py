"""Fail-closed structural checks for the skills pack (not an application security scanner).

Validates:
- required policy/template/test files exist and are non-empty
- every skill folder has SKILL.md with valid Agent Skills frontmatter
  (name == folder, lowercase/digits/hyphens, <= 64 chars, no reserved words;
   description present, <= 1024 chars, no angle brackets)
- every skill referenced in the core routing table exists
- size limits for chat-platform instruction templates
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "policy/SECURITY_POLICY.md",
    "policy/ENGINEERING_STANDARDS.md",
    "policy/CONTROL_MATRIX.csv",
    "policy/QUALITY_GATES.md",
    "ci/PR_CHECKLIST.md",
    "templates/CUSTOM_GPT_INSTRUCTIONS.md",
    "templates/SHORT_INSTRUCTIONS.md",
    "templates/REPO_INSTRUCTIONS_HEADER.md",
    ".github/workflows/security.yml",
    "tests/test_authorization.py",
    "skills/eng-core-standards/SKILL.md",
]
TEXT_LIMITS = {  # platform limits (characters)
    "templates/CUSTOM_GPT_INSTRUCTIONS.md": 8000,  # Custom GPT "Instructions" field
    "templates/SHORT_INSTRUCTIONS.md": 1500,        # ChatGPT custom-instructions field (free tier)
}
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
RESERVED = ("anthropic", "claude", "openai")


def parse_frontmatter(text: str) -> dict[str, str] | None:
    if not text.startswith("---\n"):
        return None
    end = text.find("\n---", 4)
    if end == -1:
        return None
    meta: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip()
    return meta


def main() -> int:
    errors: list[str] = []
    for name in REQUIRED:
        f = ROOT / name
        if not f.is_file() or not f.read_text(encoding="utf-8").strip():
            errors.append(f"Missing/empty {name}")

    skills = sorted((ROOT / "skills").glob("*/SKILL.md"))
    if len(skills) < 2:
        errors.append("No skills found")
    names = set()
    for p in skills:
        folder = p.parent.name
        text = p.read_text(encoding="utf-8")
        meta = parse_frontmatter(text)
        if meta is None:
            errors.append(f"{p}: missing frontmatter")
            continue
        name, desc = meta.get("name", ""), meta.get("description", "")
        if name != folder:
            errors.append(f"{p}: name '{name}' must equal folder '{folder}'")
        if not NAME_RE.match(name) or len(name) > 64:
            errors.append(f"{p}: invalid name '{name}'")
        if any(r in name for r in RESERVED):
            errors.append(f"{p}: name contains reserved word")
        if not desc or len(desc) > 1024 or "<" in desc or ">" in desc:
            errors.append(f"{p}: description missing, > 1024 chars, or contains angle brackets")
        if len(text.split("\n---", 1)[1].strip()) < 500:
            errors.append(f"{p}: body too thin")
        names.add(name)

    core = (ROOT / "skills/eng-core-standards/SKILL.md")
    if core.is_file():
        referenced = set(re.findall(r"`((?:eng|sec)-[a-z0-9-]+)`", core.read_text(encoding="utf-8")))
        for missing in sorted(referenced - names):
            errors.append(f"Core routing references unknown skill: {missing}")
        for orphan in sorted(names - referenced - {"eng-core-standards"}):
            errors.append(f"Skill not reachable from core routing table: {orphan}")

    for rel, limit in TEXT_LIMITS.items():
        f = ROOT / rel
        if f.is_file() and len(f.read_text(encoding="utf-8").strip()) > limit:
            errors.append(f"{rel}: exceeds {limit} characters")

    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print(f"Framework structure: PASS ({len(REQUIRED)} required files, {len(names)} skills)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
