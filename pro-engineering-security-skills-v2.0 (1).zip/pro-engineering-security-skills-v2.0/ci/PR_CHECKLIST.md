# Pull Request Checklist (engineering + security)

## Engineering (ENG-001 … ENG-011)
- [ ] Change is focused; no unrelated refactors or formatting noise.
- [ ] Code follows project conventions; lint, format and type checks pass.
- [ ] Tests added/updated: happy path + edge + error cases; regression test for bug fixes.
- [ ] Real test results attached (or clearly marked "not run" with reason).
- [ ] Public API / schema changes documented; backward compatible or versioned.
- [ ] DB migrations are zero-downtime (expand/contract) with rollback/roll-forward plan.
- [ ] Logs/metrics/traces added for new flows; errors are actionable and leak nothing.
- [ ] UI: loading/error/empty states, keyboard + screen-reader accessible, i18n/RTL checked.
- [ ] Docs/README/runbooks/changelog updated.

## Security (SEC-001 … SEC-014)
- [ ] Threat/risk analysis proportionate to impact (threat model for high-risk features).
- [ ] Every protected operation checks authentication + function + object + tenant authorization on the server.
- [ ] Negative tests prove unauthorized users cannot read or mutate protected resources (DB unchanged after denial).
- [ ] Inputs validated by schema; queries parameterized; output safely encoded; no dangerous HTML sinks.
- [ ] No secrets in code, config, history, bundles, logs, prompts; secret scan clean.
- [ ] Sensitive data minimized/masked; audit events present without secrets or raw PII.
- [ ] New dependencies verified (exists, maintained, license, no critical CVEs); lockfile committed.
- [ ] CI: tests, SAST, dependency, secret and IaC scans pass under blocking thresholds.
- [ ] AI-generated code reviewed like human code; AI features follow `sec-ai-llm-security`.
- [ ] Security owner approval for high-risk flows; exceptions documented with owner + expiry.
